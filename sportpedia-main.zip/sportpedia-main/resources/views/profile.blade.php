@extends('app')

@section('title')
    <title>Sporpedia</title>
@endsection

@section('css')
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.css'/>
    <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.css" type="text/css">
@endsection

@section('js')
    <script src='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.js'></script>
    <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.min.js"></script>
    <script src="{{ asset('js/mapbox.js') }}"></script>
    <script src="{{ asset('js/common.js') }}"></script>
    <script src="{{ asset('js/profile.js') }}"></script>
@endsection

@section('inline-style')
    <style>
        @media (min-width: 576px){
            .w-sm-75{
                width: 75%!important;
            }
        }

        @media (min-width: 992px){
            .w-lg-50{
                width: 50%!important;
            }
        }
    </style>
@endsection

@section('body')
<div class="px-lg-5 px-md-4 px-2 pt-5">
    <div class="py-4 d-flex justify-content-center">
        <div class="card w-sm-75 w-lg-50 w-100">
            <div class="card-body">
                <div class="d-flex justify-content-center pt-4 pb-2">
                    <img src="{{ json_decode(auth()->user()->google)->picture }}" class="img-circle img-circle-xl" alt="">
                </div>
                <div class="container mt-md-3 mt-2">
                    <div class="row">
                        <div class="col-md-2 d-flex align-items-center">
                            <span>Name</span>
                        </div>
                        <div class="col-md-10">
                            <input id="nameInput" type="text" class="form-control form-control-sm" value="{{ $user->name }}">
                        </div>
                    </div>
                    <div class="row mt-md-3 mt-2">
                        <div class="col-md-2 d-flex align-items-center">
                            <span>Email</span>
                        </div>
                        <div class="col-md-10">
                            <input id="emailInput" type="text" class="form-control form-control-sm" value="{{ $user->email }}" disabled>
                        </div>
                    </div>
                    <div class="row mt-md-3 mt-2">
                        <div class="col-md-2 d-flex align-items-center">
                            <span>Whatsapp</span>
                        </div>
                        <div class="col-md-10">
                            <input id="waInput" type="text" class="form-control form-control-sm" value="{{ $user->wa }}">
                        </div>
                    </div>
                    <div class="row mt-md-3 mt-2">
                        <div class="col-md-2">
                            <span>Address</span>
                        </div>
                        <div class="col-md-10">
                            <textarea id="addressInput" class="form-control form-control-sm">{{ $user->address }}</textarea>
                        </div>
                    </div>
                    <div class="row mt-md-3 mt-2">
                        <div class="col-md-2">
                            <span>Location</span>
                        </div>
                        <div class="col-md-10">
                            <div id="map" style="width: 100%"></div>
                            <span id="locationInput" data-lng="{{ $user->location != ''|| $user->location != null ? json_decode($user->location)->lng: '' }}" data-lat="{{ $user->location != ''|| $user->location != null ? json_decode($user->location)->lat: '' }}" hidden></span>
                        </div>
                    </div>
                    <div class="row mt-md-4 mt-3">
                        <div class="col d-flex justify-content-end">
                            <button class="btn btn-primary px-5" onclick="saveProfile()">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('#map').css('height', 0.5*( $('#map').width()));
        let centerLocation = $('#locationInput').data('lng') === ''?
            [110.387611,-7.776137]:
            [$('#locationInput').data('lng'), $('#locationInput').data('lat')];
        let map = loadMap('map', centerLocation, true, $('#locationInput').data('lng') === ''? 8: 15);
        addControl(map, new mapboxgl.NavigationControl(), 'bottom-right');
        addControl(map, new mapboxgl.FullscreenControl(), 'top-right');
        if($('#locationInput').data('lng') !== ''){
            addMarker(map, [$('#locationInput').data('lng'), $('#locationInput').data('lat')], '#DF2E2E')
        }
    });
</script>
@endsection
