@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('js')
    <script src="{{ asset('js/user.js') }}"></script>
@endsection

@section('body')
<div class="px-lg-5 px-md-4 px-3 pt-5">
    <div class="py-4">
        <div id="commonUser" class="card shadow-sm">
            <div class="card-body">
                <h5 class="fw-bold">Users</h5>
                <div class="row mt-3">
                    <div class="col-md-3">
                        <label for="nameFilter">Filter by Name</label>
                        <input id="nameFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-3 mt-md-0 mt-2">
                        <label for="emailFilter">Filter by Email</label>
                        <input id="emailFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-3 mt-md-0 mt-2">
                        <label for="statusFilter">Filter by Status</label>
                        <select id="statusFilter" class="form-select form-select-sm">
                            <option value="0" selected>All</option>
                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end justify-content-start mt-md-0 mt-2">
                        <button class="btn btn-sm btn-primary px-md-5 px-4" onclick="getUserList()">Filter</button>
                    </div>
                </div>

                <table class="table table-hover mt-md-4 mt-3 align-middle">
                    <thead>
                    <tr>
                        <th class="text-center" style="width: 35%">Name</th>
                        <th class="text-center" style="width: 35%">Email</th>
                        <th class="text-center" style="width: 20%">Status</th>
                        <th style="width: 10%"></th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <div id="loadingDiv" class="w-100 d-flex justify-content-center">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>
            </div>
        </div>

        <div id="fieldUser" class="card shadow-sm mt-3">
            <div class="card-body">
                <h5 class="fw-bold">Field Manager User</h5>
                <button class="btn btn-sm btn-primary px-3 mt-3" data-bs-toggle="modal" data-bs-target="#assignFieldManager">Assign Field Manager</button>
                <div class="row mt-3">
                    <div class="col-md-3">
                        <label for="fieldNameFilter">Filter by Name</label>
                        <input id="fieldNameFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-3 mt-md-0 mt-2">
                        <label for="fieldEmailFilter">Filter by Email</label>
                        <input id="fieldEmailFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-2 d-flex align-items-end justify-content-start mt-md-0 mt-2">
                        <button class="btn btn-sm btn-primary px-md-5 px-4" onclick="getFieldUserList()">Filter</button>
                    </div>
                </div>

                <table class="table table-hover mt-md-4 mt-3 align-middle">
                    <thead>
                    <tr>
                        <th class="text-center" style="width: 30%">Name</th>
                        <th class="text-center" style="width: 30%">Email</th>
                        <th class="text-center" style="width: 25%">Fields</th>
                        <th style="width: 15%"></th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <div id="loadingDiv" class="w-100 d-flex justify-content-center">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>
            </div>
        </div>

        <div id="productUser" class="card shadow-sm mt-3">
            <div class="card-body">
                <h5 class="fw-bold">Product Merchant User</h5>
                <button class="btn btn-sm btn-primary px-3 mt-3" data-bs-toggle="modal" data-bs-target="#assignProductUser">Assign Product User</button>
                <div class="row mt-2">
                    <div class="col-md-3 mt-md-0 mt-2">
                        <label for="productNameFilter">Filter by Name</label>
                        <input id="productNameFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-3 mt-md-0 mt-2">
                        <label for="productEmailFilter">Filter by Email</label>
                        <input id="productEmailFilter" type="text" class="form-control form-control-sm">
                    </div>
                    <div class="col-md-2 d-flex align-items-end justify-content-start mt-md-0 mt-2">
                        <button class="btn btn-sm btn-primary px-md-5 px-4" onclick="getProductUserList()">Filter</button>
                    </div>
                </div>

                <table class="table table-hover mt-md-4 mt-3 align-middle">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 30%">Name</th>
                            <th class="text-center" style="width: 30%">Email</th>
                            <th class="text-center" style="width: 25%">Products</th>
                            <th style="width: 15%"></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <div id="loadingDiv" class="w-100 d-flex justify-content-center">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="assignProductUser" class="modal fade">
    <div class="modal-dialog modal-fullscreen-md-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Assign Product User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="assignEmailInput">User Email</label>
                <input type="text" id="assignEmailInput" class="form-control form-control-sm">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm border border-primary px-3" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary px-3" onclick="assignProductUser()">Assign</button>
            </div>
        </div>
    </div>
</div>

<div id="assignFieldManager" class="modal fade">
    <div class="modal-dialog modal-fullscreen-md-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Assign Field Manager</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="assignEmailInput">User Email</label>
                <input type="text" id="assignEmailInput" class="form-control form-control-sm">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm border border-primary px-3" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary px-3" onclick="assignFieldManager()">Assign</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        getUserList();
        getFieldUserList();
        getProductUserList();
    });
</script>
@endsection
