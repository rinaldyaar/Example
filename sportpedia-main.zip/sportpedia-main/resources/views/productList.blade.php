@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('css/unite-gallery.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/product.js') }}"></script>
    <script src="{{ asset('js/unitegallery.js') }}"></script>
    <script src="{{ asset('themes/slider/ug-theme-slider.js') }}"></script>
@endsection

@section('body')
<div class="px-lg-5 px-md-4 px-2 pt-5">
    <div class="card shadow-sm mt-3">
        <div class="card-body">
            <div class="row mx-0 border-bottom border-dark">
                <h5 class="px-0">Filters</h5>
            </div>
            <div class="row row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-1 g-3 mt-1">
                <div class="col">
                    <input id="nameFilter" type="text" class="form-control form-control-sm" placeholder="Item name">
                </div>
                <div class="col">
                    <input id="priceMinFilter" type="text" class="form-control form-control-sm" placeholder="Min.Price">
                </div>
                <div class="col">
                    <input id="priceMaxFilter" type="text" class="form-control form-control-sm" placeholder="Max.Price">
                </div>
                <div class="col">
                    <button class="btn btn-sm btn-primary px-4" style="max-width: 200px" onclick="getProductList()">Filter</button>
                </div>
            </div>
        </div>
    </div>

    <h5 class="px-0 mt-3">Results</h5>
    <div id="searchResult" class="row row-cols-xl-5 row-cols-lg-4 row-cols-md-3 row-cols-2 g-3 mb-3"></div>
    <div class="w-100 d-flex justify-content-center">
        <div class="spinner-border d-none" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</div>

<div id="productModal" class="modal fade" aria-labelledby="productModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-fullscreen-md-down">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-5">
                        <div id="gallery"></div>
                    </div>
                    <div class="col-md-7 mt-md-0 mt-2">
                        <div class="text-md-start text-center">
                            <h4 class="fw-bold" id="productName"></h4>
                            <p id="productInformation"></p>
                            <h4 id="productPrice" class="fw-bolder"></h4>
                        </div>
                        <div class="d-flex justify-content-md-end justify-content-center mt-md-0 mt-3">
                            <a id="productWa" href="" target="_blank">
                                <button class="btn btn-success px-3">
                                    <i class="fab fa-whatsapp me-2"></i>
                                    Order Now
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        getProductList();
    });
</script>
@endsection
