@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('js')
    <script src="{{ asset('js/home.js') }}"></script>
@endsection

@section('inline-style')
    <style>
        .responsive-side {
            position: fixed;
        }

        .header-resize h5{
            font-size: 1.3rem;
        }

        .header-resize h4{
            font-size: 1.2rem;
        }

        .header-resize span{
            font-size: .9rem;
        }

        .header-resize span.badge{
            font-size: .7rem;
        }

        .header-resize span.text-muted{
            font-size: .85rem;
        }

        @media (max-width: 991px) {
            .responsive-side {
                position: relative;
            }
        }
    </style>
@endsection

@section('body')
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card shadow-sm">
                        <div class="container py-md-2 py-1">
                            <div class="row border-bottom border-dark">
                                <h5>My Location</h5>
                            </div>
                            <div class="input-group my-3">
                                <div type="button" class="input-group-text bg-white" onclick="getCurrentLocation()"><i class="fas fa-map-marked"></i></div>
                                <input id="myLocationInput" type="text" class="form-control form-control-sm" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3 shadow-sm">
                        <div class="container py-md-2 py-1">
                            <div class="row border-bottom border-dark">
                                <h5>Filters</h5>
                            </div>
                            <button id="nearMeBtn" class="btn btn-sm border my-3" disabled onclick="getFieldList(true)">
                                <span class="float-start pe-2"><i class="fas fa-map-marked"></i></span>
                                Near Me
                            </button>
                            <input id="placeInput" type="text" class="form-control form-control-sm" placeholder="Place or Address">
                            <select id="typeInput" class="form-select form-select-sm my-3">
                                <option value="0" selected>--Field Type--</option>
                                <option value="1">Basket</option>
                                <option value="2">Badminton</option>
                                <option value="3">Futsal</option>
                                <option value="4">Volley</option>
                                <option value="5">Tennis</option>
                                <option value="6">Soccer</option>
                                <option value="7">Table Tennis</option>
                                <option value="8">Mini Soccer</option>
                            </select>
                            <div class="row my-3">
                                <div class="col-5">
                                    <input id="priceMin" type="text" class="form-control form-control-sm" placeholder="Min.Price">
                                </div>
                                <div class="col-2 d-flex justify-content-center">to</div>
                                <div class="col-5">
                                    <input id="priceMax" type="text" class="form-control form-control-sm" placeholder="Max.Price">
                                </div>
                            </div>
                            <div class="float-end mb-3">
                                <button class="btn btn-sm btn-outline-primary px-5" onclick="getFieldList()">Filter</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 mt-lg-0 mt-3" style="font-size: .75rem">
                    <div id="searchResult"></div>
                    <div class="w-100 d-flex justify-content-center">
                        <div class="spinner-border d-none" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            getFieldList();
        });
    </script>
@endsection
