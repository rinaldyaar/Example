@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('js')
    <script src="{{ asset('js/common.js') }}"></script>
    <script src="{{ asset('js/product.js') }}"></script>
@endsection

@section('body')
    <span id="hidden-type">{{ $operation }}</span>
    <span id="hidden-id">{{ $product->id }}</span>
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="container">
                        <h5 class="card-title">{{ $operation }} Product</h5>
                        <div class="row mt-lg-4 mt-md-3 mt-2">
                            <div class="col-md-2 d-flex align-items-center">
                                <span>Product Name</span>
                            </div>
                            <div class="col-md-10">
                                <input id="nameInput" type="text" class="form-control form-control-sm" value="{{ $product->name }}">
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Product Information</span>
                            </div>
                            <div class="col-md-10">
                                <textarea id="informationInput" class="form-control form-control-sm">{{ $product->information }}</textarea>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Product Images</span>
                            </div>
                            <div class="col-md-10">
                                <div class="row row-cols-lg-3 row-cols-md-2 row-cols-1">
                                    @foreach(json_decode($product->images) as $image)
                                        <div class="col d-md-block d-flex justify-content-center mt-2">
                                            <img src="{{ $image }}" alt="" class="w-100">
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Price</span>
                            </div>
                            <div class="col-md-5">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">Rp</span>
                                    <input id="priceInput" type="text" class="form-control form-control-sm" value="{{ number_format($product->price, 0, ',', '.') }}">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Whatsapp</span>
                            </div>
                            <div class="col-md-5">
                                <input id="waInput" type="text" class="form-control form-control-sm" value="{{ $product->wa }}">
                                <small class="text-muted">Whatsapp number start with 62, not 0. Example: 6282234567890.</small>
                            </div>
                        </div>
                        @if($operation == 'Edit')
                            <div class="row mt-md-4 mt-3 mb-3">
                                <div class="col d-flex justify-content-end">
                                    <button class="btn btn-sm btn-outline-primary px-4" onclick="updateProduct()">Update Product</button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    </script>
@endsection
