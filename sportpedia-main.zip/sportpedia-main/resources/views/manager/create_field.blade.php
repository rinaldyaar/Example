@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('css')
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.css'/>
    <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.css" type="text/css">
@endsection

@section('js')
    <script src='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.js'></script>
    <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.min.js"></script>
    <script src="{{ asset('js/mapbox.js') }}"></script>
    <script src="{{ asset('js/common.js') }}"></script>
    <script src="{{ asset('js/field.js') }}"></script>
@endsection

@section('body')
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="container">
                        <h5 class="card-title">Register New Field</h5>
                        <div class="row mt-lg-4 mt-md-3 mt-2">
                            <div class="col-md-2 d-flex align-items-center">
                                <span>Field Name</span>
                            </div>
                            <div class="col-md-7">
                                <input id="nameInput" type="text" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-1 mt-md-0 mt-2 d-flex align-item-center">
                                <span>Type</span>
                            </div>
                            <div class="col-md-2">
                                <select id="typeInput" class="form-select form-select-sm">
                                    <option value="0" selected>--Field Type--</option>
                                    <option value="1">Basket</option>
                                    <option value="2">Badminton</option>
                                    <option value="3">Futsal</option>
                                    <option value="4">Volley</option>
                                    <option value="5">Tennis</option>
                                    <option value="6">Soccer</option>
                                    <option value="7">Table Tennis</option>
                                    <option value="8">Mini Soccer</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Field Information</span>
                            </div>
                            <div class="col-md-10">
                                <textarea id="informationInput" class="form-control form-control-sm"></textarea>
                                <small class="text-muted">Can be filled with information about facilities, how to access the field, etc.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Field Images</span>
                            </div>
                            <div class="col-md-10">
                                <input type="file" id="imagesInput" class="form-control form-control-sm" accept="image/*" multiple onchange="openFileInput(this)">
                                <div class="row row-cols-lg-3 row-cols-md-2 row-cols-1">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Opening Hours</span>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-5">
                                        <input id="startTimeInput" type="time" class="form-control form-control-sm" placeholder="Start Time">
                                    </div>
                                    <div class="col-2 d-flex justify-content-center">
                                        <span>until</span>
                                    </div>
                                    <div class="col-5">
                                        <input id="endTimeInput" type="time" class="form-control form-control-sm" placeholder="Stop Time">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Prices</span>
                            </div>
                            <div id="pricesInput" class="col-md-8">
                                <div class="row price-row">
                                    <div class="col-md-7 pe-md-3">
                                        <input type="text" class="form-control form-control-sm price-name" placeholder="Price Name">
                                    </div>
                                    <div class="col-md-5">
                                        <div class="row mt-md-0 mt-1">
                                            <div class="col-8">
                                                <div class="input-group input-group-sm">
                                                    <span class="input-group-text">Rp</span>
                                                    <input type="text" class="form-control price-value" placeholder="Price">
                                                </div>
                                            </div>
                                            <div class="col p-0">
                                                <button class="btn btn-sm border" onclick="removePrice(this)">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-sm border mt-2" onclick="addPrice(this)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Whatsapp</span>
                            </div>
                            <div class="col-md-5">
                                <input id="waInput" type="text" class="form-control form-control-sm">
                                <small class="text-muted">Whatsapp number start with 62, not 0. Example: 6282234567890.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Address</span>
                            </div>
                            <div class="col-md-10">
                                <textarea id="addressInput" class="form-control form-control-sm"></textarea>
                                <small class="text-muted">Full address of the field.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Location</span>
                            </div>
                            <div class="col-md-10">
                                <div id="map" style="width: 100%"></div>
                                <span id="locationInput" hidden></span>
                            </div>
                        </div>
                        <div class="row mt-md-4 mt-3 mb-3">
                            <div class="col d-flex justify-content-end">
                                <button class="btn btn-sm btn-outline-primary px-4" onclick="createField()">Register Field</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $('#map').css('height', 0.5*( $('#map').width()));
            let map = loadMap('map', [110.387611,-7.776137], true, 8);
            addControl(map, new mapboxgl.NavigationControl(), 'bottom-right');
            addControl(map, new mapboxgl.FullscreenControl(), 'top-right');
            if($(window).width() > 991) {
                addControl(map, new MapboxGeocoder({
                    accessToken: mapboxgl.accessToken,
                    localGeocoder: coordinatesGeocoder,
                    zoom: 13,
                    placeholder: 'Search...',
                    mapboxgl: mapboxgl,
                    reverseGeocode: true
                }), 'top-left');
            }
        });
    </script>
@endsection
