@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/unite-gallery.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/product.js') }}"></script>
    <script src="{{ asset('js/unitegallery.js') }}"></script>
    <script src="{{ asset('themes/compact/ug-theme-compact.js') }}"></script>
@endsection

@section('inline-style')
    <style>
        .card-inactive {
            background-color: rgba(0,0,0,.1);
        }

        .card-footer>button:hover {
            background-color: #cbd5e0;
        }
    </style>
@endsection

@section('body')
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <a href="{{ route('manager.createProduct') }}">
                <button class="btn btn-sm btn-outline-primary px-3">
                    <i class="fas fa-plus-circle"></i>
                    <span class="ps-1 fw-bold">New Product</span>
                </button>
            </a>
            <h5 class="mt-3">Your Products</h5>
            <div id="productContainer" class="row row-cols-xl-5 row-cols-lg-4 row-cols-md-3 row-cols-2">
{{--                <div class="col" data-id="1">--}}
{{--                    <div class="card">--}}
{{--                        <img type="button" src="/upload/ihsan syarifuddin/test product 1/img_148073.png" class="card-img-top" alt="" onclick="loadProductModal(this)">--}}
{{--                        <div class="card-body text-center">--}}
{{--                            <h5 type="button" class="card-title" onclick="loadProductModal(this)">test product 1</h5>--}}
{{--                            <p>Rp 50000</p>--}}
{{--                        </div>--}}
{{--                        <div class="card-footer btn-group p-0">--}}
{{--                            <button class="btn btn-sm border-end py-2" style="width: 33.3333%">--}}
{{--                                View--}}
{{--                            </button>--}}
{{--                            <button class="btn btn-sm border-end py-2" style="width: 33.3333%">--}}
{{--                                Edit--}}
{{--                            </button>--}}
{{--                            <button class="btn btn-sm py-2" style="width: 33.3333%">--}}
{{--                                Delete--}}
{{--                            </button>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
        </div>
    </div>

{{--    <div id="productModal" class="modal fade">--}}
{{--        <div class="modal-dialog modal-lg modal-fullscreen-md-down">--}}
{{--            <div class="modal-content">--}}
{{--                <div class="modal-header">--}}
{{--                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>--}}
{{--                </div>--}}
{{--                <div class="modal-body">--}}
{{--                    <div class="container-fluid">--}}
{{--                        <div class="row">--}}
{{--                            <div class="col-md-5">--}}
{{--                                <div id="gallery"></div>--}}
{{--                            </div>--}}
{{--                            <div class="col-md-7">--}}
{{--                                <div class="p-3">--}}
{{--                                    <h5>test product 1</h5>--}}
{{--                                    <p class="fst-italic">test</p>--}}
{{--                                    <span class="fw-bold fs-2">Rp 50000</span>--}}
{{--                                    <div class="w-100 d-flex justify-content-end">--}}
{{--                                        <button class="btn btn-success">--}}
{{--                                            <i class="fab fa-whatsapp"></i>--}}
{{--                                            Order Now</button>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}

    <script>
        $(document).ready(function(){
            getManagerProductData();
        });
    </script>
@endsection
