@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('css')
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.css'/>
    <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.css" type="text/css">
@endsection

@section('js')
    <script src='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.js'></script>
    <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.min.js"></script>
    <script src="{{ asset('js/mapbox.js') }}"></script>
    <script src="{{ asset('js/common.js') }}"></script>
    <script src="{{ asset('js/field.js') }}"></script>
@endsection

@section('body')
    <span id="hidden-type" hidden>{{ $operation }}</span>
    <span id="hidden-id" hidden>{{ $field->id }}</span>
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="container">
                        <h5 class="card-title">{{ $operation }} Field</h5>
                        <div class="row mt-lg-4 mt-md-3 mt-2">
                            <div class="col-md-2 d-flex align-items-center">
                                <span>Field Name</span>
                            </div>
                            <div class="col-md-7">
                                <input id="nameInput" type="text" class="form-control form-control-sm" value="{{ $field->name }}">
                            </div>
                            <div class="col-md-1 mt-md-0 mt-2 d-flex align-item-center">
                                <span>Type</span>
                            </div>
                            <div class="col-md-2">
                                <select id="typeInput" class="form-select form-select-sm">
                                    <option value="0" {{ $field->type == 0? 'selected': '' }}>--Field Type--</option>
                                    <option value="1" {{ $field->type == 1? 'selected': '' }}>Basket</option>
                                    <option value="2" {{ $field->type == 2? 'selected': '' }}>Badminton</option>
                                    <option value="3" {{ $field->type == 3? 'selected': '' }}>Futsal</option>
                                    <option value="4" {{ $field->type == 4? 'selected': '' }}>Volley</option>
                                    <option value="5" {{ $field->type == 5? 'selected': '' }}>Tennis</option>
                                    <option value="6" {{ $field->type == 6? 'selected': '' }}>Soccer</option>
                                    <option value="7" {{ $field->type == 7? 'selected': '' }}>Table Tennis</option>
                                    <option value="8" {{ $field->type == 8? 'selected': '' }}>Mini Soccer</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Field Information</span>
                            </div>
                            <div class="col-md-10">
                                <textarea id="informationInput" class="form-control form-control-sm">{{ $field->information }}</textarea>
                                <small class="text-muted">Can be filled with information about facilities, how to access the field, etc.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Field Images</span>
                            </div>
                            <div class="col-md-10">
                                <div class="row row-cols-lg-3 row-cols-md-2 row-cols-1">
                                    @foreach(json_decode($field->images) as $image)
                                        <div class="col d-md-block d-flex justify-content-center mt-2">
                                            <img src="{{ $image }}" alt="" class="w-100">
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Opening Hours</span>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-5">
                                        <input id="startTimeInput" type="time" class="form-control form-control-sm" placeholder="Start Time" value="{{ json_decode($field->opening_hours)->open }}">
                                    </div>
                                    <div class="col-2 d-flex justify-content-center">
                                        <span>until</span>
                                    </div>
                                    <div class="col-5">
                                        <input id="endTimeInput" type="time" class="form-control form-control-sm" placeholder="Stop Time" value="{{ json_decode($field->opening_hours)->close }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Prices</span>
                            </div>
                            <div id="pricesInput" class="col-md-8">
                                @foreach(json_decode($field->prices) as $price)
                                    <div class="row price-row mt-3">
                                        <div class="col-md-7 pe-md-3">
                                            <input type="text" class="form-control form-control-sm price-name" placeholder="Price Name" value="{{ $price->name }}">
                                        </div>
                                        <div class="col-md-5">
                                            <div class="row mt-md-0 mt-1">
                                                <div class="col-8">
                                                    <div class="input-group input-group-sm">
                                                        <span class="input-group-text">Rp</span>
                                                        <input type="text" class="form-control price-value" placeholder="Price" value="{{ $price->value }}">
                                                    </div>
                                                </div>
                                                @if($operation == 'Edit')
                                                    <div class="col p-0">
                                                        <button class="btn btn-sm border" onclick="removePrice(this)">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                <button class="btn btn-sm border mt-2" onclick="addPrice(this)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Whatsapp</span>
                            </div>
                            <div class="col-md-5">
                                <input id="waInput" type="text" class="form-control form-control-sm" value="{{ $field->wa }}">
                                <small class="text-muted">Whatsapp number start with 62, not 0. Example: 6282234567890.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Address</span>
                            </div>
                            <div class="col-md-10">
                                <textarea id="addressInput" class="form-control form-control-sm">{{ $field->address }}</textarea>
                                <small class="text-muted">Full address of the field.</small>
                            </div>
                        </div>
                        <div class="row mt-md-3 mt-2">
                            <div class="col-md-2">
                                <span>Location</span>
                            </div>
                            <div class="col-md-10">
                                <div id="map" style="width: 100%"></div>
                                <span id="locationInput" data-lng="{{ json_decode($field->location)->lng }}" data-lat="{{ json_decode($field->location)->lat }}" hidden></span>
                            </div>
                        </div>
                        @if($operation == 'Edit')
                            <div class="row mt-md-4 mt-3 mb-3">
                                <div class="col d-flex justify-content-end">
                                    <button class="btn btn-sm btn-outline-primary px-4" onclick="updateField()">Update Field</button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $('#map').css('height', 0.5*( $('#map').width()));
            let lng = $('#locationInput').data('lng');
            let lat = $('#locationInput').data('lat');
            let map = loadMap('map', [lng,lat]);
            addMarker(map, [lng, lat], '#DF2E2E');
        });
    </script>
@endsection
