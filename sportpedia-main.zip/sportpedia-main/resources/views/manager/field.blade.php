@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('js')
    <script src="{{ asset('js/field.js') }}"></script>
@endsection

@section('inline-style')
    <style>
        .card-inactive {
            background-color: rgba(0,0,0,.1);
        }

        .card-footer>button:hover {
            background-color: #cbd5e0;
        }
    </style>
@endsection

@section('body')
<div class="px-lg-5 px-md-4 px-2 pt-5">
    <div class="py-4">
        <a href="{{ route('manager.create_field') }}">
            <button class="btn btn-sm btn-outline-primary px-3">
                <i class="fas fa-plus-circle"></i>
                <span class="ps-1 fw-bold">New Field</span>
            </button>
        </a>
        <h5 class="mt-3">Your Fields</h5>
        <div id="ownerFieldContainer" class="row row-cols-xl-5 row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-md-1">
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        getManagerFieldData();
    });
</script>
@endsection
