@extends('app')

@section('title')
    <title>Sportpedia - Homepage</title>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/unite-gallery.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/field.js') }}"></script>
    <script src="{{ asset('js/product.js') }}"></script>
    <script src="{{ asset('js/unitegallery.js') }}"></script>
    <script src="{{ asset('themes/slider/ug-theme-slider.js') }}"></script>
{{--    <script src="https://cdn.jsdelivr.net/npm/masonry-layout@4.2.2/dist/masonry.pkgd.min.js" integrity="sha384-GNFwBvfVxBkLMJpYMOABq3c+d3KnQxudP/mGPkzpZSTYykLBNsZEnG2D9G/X/+7D" crossorigin="anonymous" async></script>--}}
@endsection

@section('inline-style')
    <style>
        .banner>img {
            height: 300px;
        }

        .img-gradient {
            position:relative;
        }


        .img-gradient::after {
            content: '';
            position: absolute;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background: linear-gradient(rgba(0, 0, 0, 0.1),rgba(0, 0, 0, 0.5));
        }

        .static-caption {
            position:absolute;
            z-index:1;
            pointer-events:none;
        }

        .category-image {
            width: 130px;
            height: 130px;
        }

        .category-image>img {
            width: 50%;
        }

        .category-image:hover {
            background-color: #0050d1;
            cursor: pointer;
        }

        .category-image:hover>img {
            filter: invert(1);
        }

        @media (min-width: 576px) {
            .banner>img {
                height: 450px;
            }
        }

        @media (min-width: 992px) {
            .banner>img {
                height: 600px;
            }
        }
    </style>
@endsection

@section('body')
<span id="hidden-product" hidden>{{ json_encode($products) }}</span>
<div class="banner img-gradient">
    <div class="h-100 w-100 static-caption">
        <div class="d-flex justify-content-center text-center h-100">
            <div class="my-auto w-75 text-light">
                <h3>Welcome to</h3>
                <h1 class="fw-bold">SPORTPEDIA INDONESIA</h1>
                <p>Sportpedia is a sports venue reservation service provider website. Sportpedia also offers original sports equipment.</p>
            </div>
        </div>
    </div>
    <img src="{{ asset('images/banner.webp') }}" class="w-100" alt="">
</div>

<div class="px-xl-5 px-lg-4 px-md-3 px-2 my-md-5 my-4 w-100">
    <div class="row row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-1 g-4">
        <div class="col" onclick="basicFilter('badminton')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTExLjk4NSA1MTEuOTg1IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTEuOTg1IDUxMS45ODU7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNDk5LjQ1NSwyMzAuNjczbC03NS42MTYtMTYuOTI4bC0yMjIuOTc2LDE3MS4zNmwtMjIuODE2LTIyLjgxNmwyMjguNjcyLTE3NS43MTJsLTYuODQ4LTYwLjM4NA0KCQkJYy0wLjgzMi03LjQyNC02LjY4OC0xMy4yOC0xNC4wOC0xNC4wOGwtNjQuNTQ0LTcuMzI4bC0xNzEuODQsMjI4Ljg5NmwtMjIuODE2LTIyLjg0OEwzMDAuMjIzLDc5LjUwNWwtNy4zNi02NS4zMTINCgkJCWMtMC40NDgtNC4zODQtMi43ODQtOC4zODQtNi4zMDQtMTEuMDA4Yy0zLjUyLTIuNjI0LTgtMy43MTItMTIuMzUyLTIuOTQ0bC05MC40OTYsMTZjLTUuNzkyLDEuMDI0LTEwLjUyOCw1LjA4OC0xMi40MTYsMTAuNjU2DQoJCQlMODEuOTgzLDI5NC4xOTNsLTI2LjU5MiwyNi41OTJsMTM1Ljc0NCwxMzUuNzQ0bDI2LjU2LTI2LjU2bDI2Ny4yOTYtODkuMzEyYzUuNDQtMS44MjQsOS41MDQtNi40LDEwLjYyNC0xMi4wMzJsMTYtNzkuMTY4DQoJCQlDNTEzLjM3NSwyNDAuOTQ1LDUwNy45NjcsMjMyLjU5Myw0OTkuNDU1LDIzMC42NzN6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0zMi43NjcsMzQzLjQ0MWwtNC42NzIsNC42NzJjLTM3LjQwOCwzNy40NC0zNy40MDgsOTguMzA0LDAsMTM1Ljc0NGMxOC4xMTIsMTguMTQ0LDQyLjI0LDI4LjEyOCw2Ny44NzIsMjguMTI4DQoJCQlzNDkuNzYtMTAuMDE2LDY3Ljg3Mi0yOC4xMjhsNC42NzItNC42NzJMMzIuNzY3LDM0My40NDF6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo="/>
                    </div>
                </div>
                <h5 class="mt-3">Badminton</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('basket')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0yMzYuMzIsMi4wOGwtMC4yODgtMS43MjhDMTgyLjE3Niw0LjU0NCwxMjkuNTM2LDI1LjcyOCw4Ni40NjQsNjMuNzc2TDI1NiwyMzMuMzQ0bDU3LjQwOC01Ny40MDgNCgkJCUMyNzAuMjcyLDEyNi4wNDgsMjQ1LjI4LDU0Ljk0NCwyMzYuMzIsMi4wOHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTI2OC42NCwwYzguNTQ0LDQ3LjUyLDMwLjQzMiwxMDkuNTM2LDY3LjQ1NiwxNTMuMjQ4bDg5LjQ0LTg5LjQ0QzM4MC41MTIsMjQuMDMyLDMyNS4wMjQsMi43NTIsMjY4LjY0LDB6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik00NDguMjI0LDg2LjQ2NGwtODkuNDQsODkuNDRDNDAyLjQ2NCwyMTIuOTI4LDQ2NC40OCwyMzQuODQ4LDUxMiwyNDMuMzZDNTA5LjI0OCwxODYuOTc2LDQ4OCwxMzEuNDg4LDQ0OC4yMjQsODYuNDY0eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cG9seWdvbiBwb2ludHM9Ijc0LjQ5Niw3NC42MjQgNzQuNTYsNzQuNTYgNzQuNjI0LDc0LjQ2NCAJCSIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNjMuNzc2LDg2LjQ2NEMyNS43MjgsMTI5LjUzNiw0LjU0NCwxODIuMTc2LDAuMzUyLDIzNi4wMzJsMS43MjgsMC4yODhjNTIuODY0LDguOTYsMTIzLjk2OCwzMy45NTIsMTczLjg1Niw3Ny4wODgNCgkJCUwyMzMuMzQ0LDI1Nkw2My43NzYsODYuNDY0eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMCwyNjguNjRjMi43NTIsNTYuMzg0LDI0LjAzMiwxMTEuODcyLDYzLjgwOCwxNTYuOTI4bDg5LjQ0LTg5LjQ0QzEwOS41MzYsMjk5LjA3Miw0Ny41MiwyNzcuMTUyLDAsMjY4LjY0eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMTc1LjkwNCwzNTguNzUybC04OS40NCw4OS40NzJDMTMxLjQ4OCw0ODgsMTg3LjAwOCw1MDkuMjQ4LDI0My4zNiw1MTJDMjM0LjgxNiw0NjQuNDgsMjEyLjkyOCw0MDIuNDY0LDE3NS45MDQsMzU4Ljc1MnoNCgkJCSIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjU2LDI3OC42ODhsLTU3LjM3Niw1Ny4zNzZjNDMuMTA0LDQ5Ljg4OCw2OC4wNjQsMTIwLjk5Miw3Ny4wNTYsMTczLjgyNGwwLjI4OCwxLjcyOA0KCQkJYzUzLjg1Ni00LjE5MiwxMDYuNDk2LTI1LjM3NiwxNDkuNTY4LTYzLjQyNEwyNTYsMjc4LjY4OHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTUwOS45MiwyNzUuNjhjLTUyLjg2NC04Ljk5Mi0xMjMuOTY4LTMzLjk1Mi0xNzMuODU2LTc3LjA1NkwyNzguNjg4LDI1NmwxNjkuNTM2LDE2OS41MzYNCgkJCWMzOC4wNDgtNDMuMDcyLDU5LjI2NC05NS43MTIsNjMuNDI0LTE0OS41NjhMNTA5LjkyLDI3NS42OHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==" />
                    </div>
                </div>
                <h5 class="mt-3">Basket</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('soccer')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0yNTYsMEMxMTQuODQ4LDAsMCwxMTQuODQ4LDAsMjU2czExNC44NDgsMjU2LDI1NiwyNTZzMjU2LTExNC44NDgsMjU2LTI1NlMzOTcuMTUyLDAsMjU2LDB6IE0yNzIuMjU2LDgzLjE2OA0KCQkJbDY1LjgyNC0zNS4zOTJjMzYuNDQ4LDE0LjQzMiw2OC4yNTYsMzguMDgsOTIuNDQ4LDY4LjE2bC0xNS42OCw3Mi4zODRsLTUwLjIwOCwyNC42MDhsLTkyLjM4NC02Ny4yOTZWODMuMTY4eiBNMTc0LjQ2NCw0Ny41ODQNCgkJCWw2NS44MjQsMzUuNTJ2NjIuNTI4bC05Mi4zMiw2Ny4yOTZsLTUwLjQ2NC0yNC42NGwtMTUuNjgtNzIuODMyQzEwNi4wOCw4NS40NCwxMzcuOTUyLDYxLjkyLDE3NC40NjQsNDcuNTg0eiBNNzEuMzYsMzgyLjUyOA0KCQkJYy0yMC44OTYtMzAuNC0zNC40OTYtNjYuMTQ0LTM4LjI0LTEwNC43NjhsNTQuMTc2LTU4Ljg0OGw0OS40MDgsMjQuMTZsMzcuMjE2LDEwNS42OTZsLTMxLjQ1NiwzNy42OTZMNzEuMzYsMzgyLjUyOHoNCgkJCSBNMzEzLjA1Niw0NzIuMzUyQzI5NC43ODQsNDc3LjE4NCwyNzUuNzQ0LDQ4MCwyNTYsNDgwYy0yMy44NzIsMC00Ni44NDgtMy44NC02OC40NDgtMTAuNzg0bC0yMC4xMjgtNjIuNjU2TDE5OS41MiwzNjhoMTEzLjA4OA0KCQkJbDMxLjUyLDM3LjMxMkwzMTMuMDU2LDQ3Mi4zNTJ6IE0zNjkuMDg4LDM4NS4zNzZsLTMwLjk0NC0zNi42NGwzNy43MjgtMTA1LjY2NGw0OS4xODQtMjQuMDk2bDUzLjg1Niw1OC44MTYNCgkJCWMtMy4yMzIsMzMuMzEyLTEzLjk1Miw2NC4zODQtMzAuMjQsOTEuODcyTDM2OS4wODgsMzg1LjM3NnoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==" />
                    </div>
                </div>
                <h5 class="mt-3">Soccer</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('volley')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyLjAzMiA1MTIuMDMyIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTIuMDMyIDUxMi4wMzI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjY5LjUzNiwyNjUuNjMyYy04LjU3NiwxMTkuNDg4LTczLjI0OCwxODkuODU2LTExNy44ODgsMjI0LjQxNmMyMS4wODgsOS40NCw0My42OCwxNiw2Ny4zMjgsMTkuNDU2bDkuNjk2LTcuODcyDQoJCQljNTguNjg4LTQ3LjU4NCwxMjkuNjk2LTEzMi4yMjQsMTQ2LjExMi0yNjUuNTY4QzM0Mi4xMTIsMjM4LjQzMiwzMDYuNzUyLDI0Ny4zMjgsMjY5LjUzNiwyNjUuNjMyeiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNTAyLjA4LDE4NS4yMTZsLTEyLjk2LTcuOTY4Yy00Ni4zMDQtMjguNTQ0LTE2Ny41NTItODUuOTUyLTMxNS4xMzYtMjQuNTEyYzE4LjY1NiwyOS41MDQsNDUuMDg4LDU4LjMwNCw4Mi4zNjgsODMuNDU2DQoJCQljMTA2Ljk0NC01Mi4xOTIsMjAxLjI4LTMxLjI2NCwyNTQuMDE2LTEwLjE0NEM1MDguNzA0LDIxMi4wNjQsNTA1Ljg4OCwxOTguNDMyLDUwMi4wOCwxODUuMjE2eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjU2LjEyOCwwLjAzMmMtNDQuOTYsMC04Ny4yLDExLjY4LTEyMy45MzYsMzIuMDY0bDAuMTI4LDEuMTUyYzIuOTc2LDI3LjA0LDEwLjY1Niw1OC45NDQsMjYuMDQ4LDkxLjM2DQoJCQlDMzAwLjQxNiw2NCw0MjAuNTEyLDEwNC41MTIsNDgyLjYyNCwxMzYuOEM0MzkuNzEyLDU1LjQ4OCwzNTQuNDMyLDAuMDMyLDI1Ni4xMjgsMC4wMzJ6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0xMDIuNzIsNTEuNDI0Yy0yMC44LDE1LjYxNi0zOS4xMzYsMzQuMjQtNTQuMzM2LDU1LjM2bDEuMzc2LDguOTI4YzExLjY0OCw3NS4xMDQsNDguMTkyLDE4MC41NDQsMTUzLjk1MiwyNjUuMDU2DQoJCQljMTcuNDcyLTMxLjQ4OCwzMC43NTItNzAuNTI4LDM0LjA0OC0xMTguNTI4QzE0NS4yNDgsMTk5LjQ4OCwxMTIuNjcyLDExNi4wOTYsMTAyLjcyLDUxLjQyNHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTIzLjU1MiwxNDkuMzc2QzguNTc2LDE4MS45NTIsMCwyMTguMDgsMCwyNTYuMjU2YzAsOTEuNjgsNDguMjg4LDE3MS44NzIsMTIwLjY0LDIxNy4xNTJsMy4wNzItMi4yMDgNCgkJCWMxOC4xMTItMTIuOTYsNDEuNjY0LTMzLjkyLDYyLjg0OC02My4yMzJDODMuNjgsMzI2Ljk3Niw0MC43MzYsMjI3LjY4LDIzLjU1MiwxNDkuMzc2eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNTA3LjcxMiwyNTkuNjhjLTI2Ljg4LTExLjkwNC02MS4yNDgtMjIuMTQ0LTEwMC42MDgtMjQuMDk2Yy0xNS4yLDEzNC4wOC04MS40NCwyMjIuNTkyLTE0MS43MjgsMjc2LjQxNg0KCQkJYzEzNS4zNi00LjgzMiwyNDMuODQtMTE0LjQ5NiwyNDYuNjU2LTI1MC40MzJMNTA3LjcxMiwyNTkuNjh6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo=" />
                    </div>
                </div>
                <h5 class="mt-3">Volley</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('table_tennis')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxjaXJjbGUgY3g9IjM1MS43MjQiIGN5PSI2NCIgcj0iNjQiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTQ5Ny42NDQsNDMwLjA4bC05MS44NC05MS44NGMtNC44LTQuOC02LjA4LTEyLjE2LTIuODgtMTcuOTJjMjQuNzM2LTQ1LjI0OCwzMC45NDQtOTYuNzY4LDIwLjA5Ni0xNDQuOTkybC0yNDgsMjQ3Ljk2OA0KCQkJYzQ4LjIyNCwxMC44NDgsOTkuNzc2LDQuNjQsMTQ1LjAyNC0yMC4wOTZjNS43Ni0zLjIsMTMuMTItMS45MiwxNy45MiwyLjg4bDkxLjg0LDkxLjg0YzkuMjgsOS42LDIxLjc2LDE0LjA4LDMzLjkyLDE0LjA4DQoJCQlzMjQuNjQtNC40OCwzMy45Mi0xNC4wOEM1MTYuNTI0LDQ3OS4zNiw1MTYuNTI0LDQ0OC42NCw0OTcuNjQ0LDQzMC4wOHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTQxMS4wMiwxMzguOTc2QzM5NC42MzYsMTUxLjkzNiwzNzQuMjIsMTYwLDM1MS43MjQsMTYwYy01My4wMjQsMC05Ni00Mi45NzYtOTYtOTZjMC0xNy45ODQsNS4yNDgtMzQuNjI0LDEzLjg4OC00OS4wMjQNCgkJCUMxOTMuOTY0LTEwLjQzMiwxMDYuMDYtNC4zNTIsNTAuNjA0LDUwLjg4Yy04Mi41Niw4Mi44OC01NS42OCwyMzguNCwyMi43MiwzMTYuOGMxOS43MTIsMTkuNzEyLDQyLjcyLDM0LjQsNjcuNDg4LDQ0LjYwOA0KCQkJbDI3MS4yLTI3MS4xNjhDNDExLjcyNCwxNDAuMzg0LDQxMS4zNCwxMzkuNjgsNDExLjAyLDEzOC45NzZ6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo=" />
                    </div>
                </div>
                <h5 class="mt-3">Table Tennis</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('futsal')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img style="transform: rotate(36deg)" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0yNTYsMEMxMTQuODQ4LDAsMCwxMTQuODQ4LDAsMjU2czExNC44NDgsMjU2LDI1NiwyNTZzMjU2LTExNC44NDgsMjU2LTI1NlMzOTcuMTUyLDAsMjU2LDB6IE0yNzIuMjU2LDgzLjE2OA0KCQkJbDY1LjgyNC0zNS4zOTJjMzYuNDQ4LDE0LjQzMiw2OC4yNTYsMzguMDgsOTIuNDQ4LDY4LjE2bC0xNS42OCw3Mi4zODRsLTUwLjIwOCwyNC42MDhsLTkyLjM4NC02Ny4yOTZWODMuMTY4eiBNMTc0LjQ2NCw0Ny41ODQNCgkJCWw2NS44MjQsMzUuNTJ2NjIuNTI4bC05Mi4zMiw2Ny4yOTZsLTUwLjQ2NC0yNC42NGwtMTUuNjgtNzIuODMyQzEwNi4wOCw4NS40NCwxMzcuOTUyLDYxLjkyLDE3NC40NjQsNDcuNTg0eiBNNzEuMzYsMzgyLjUyOA0KCQkJYy0yMC44OTYtMzAuNC0zNC40OTYtNjYuMTQ0LTM4LjI0LTEwNC43NjhsNTQuMTc2LTU4Ljg0OGw0OS40MDgsMjQuMTZsMzcuMjE2LDEwNS42OTZsLTMxLjQ1NiwzNy42OTZMNzEuMzYsMzgyLjUyOHoNCgkJCSBNMzEzLjA1Niw0NzIuMzUyQzI5NC43ODQsNDc3LjE4NCwyNzUuNzQ0LDQ4MCwyNTYsNDgwYy0yMy44NzIsMC00Ni44NDgtMy44NC02OC40NDgtMTAuNzg0bC0yMC4xMjgtNjIuNjU2TDE5OS41MiwzNjhoMTEzLjA4OA0KCQkJbDMxLjUyLDM3LjMxMkwzMTMuMDU2LDQ3Mi4zNTJ6IE0zNjkuMDg4LDM4NS4zNzZsLTMwLjk0NC0zNi42NGwzNy43MjgtMTA1LjY2NGw0OS4xODQtMjQuMDk2bDUzLjg1Niw1OC44MTYNCgkJCWMtMy4yMzIsMzMuMzEyLTEzLjk1Miw2NC4zODQtMzAuMjQsOTEuODcyTDM2OS4wODgsMzg1LjM3NnoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==" />
                    </div>
                </div>
                <h5 class="mt-3">Futsal</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('tennis')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTExLjk2OCA1MTEuOTY4IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTEuOTY4IDUxMS45Njg7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNDY4LjI5LDQzLjc3NmMtNjIuNC02Mi40LTE2OS4wMjQtNTcuMjgtMjM3LjYsMTEuMzI4Yy0zMy41MDQsMzMuNDcyLTUyLjk5Miw3Ni44LTU0LjkxMiwxMjEuOTg0bC02LjA4LDE0Mi42MjQNCgkJCWwtNTYuMTkyLDU2LjE5MmMtMTcuNzYtNy45NjgtNDAtNS4yNDgtNTQuMTc2LDguOTI4TDE0LjA4Miw0MzAuMDhjLTE4LjcyLDE4LjcyLTE4LjcyLDQ5LjE1MiwwLDY3Ljg3Mg0KCQkJYzkuMzQ0LDkuMzQ0LDIxLjYzMiwxNC4wMTYsMzMuOTUyLDE0LjAxNnMyNC41NzYtNC42NzIsMzMuOTUyLTE0LjAxNmw0NS4yNDgtNDUuMjQ4YzE0LjcyLTE0LjcyLDE3LjQ0LTM2LjQ4LDkuMDI0LTU0LjI3Mg0KCQkJbDU2LjA2NC01Ni4wNjRsMTQyLjYyNC02LjA0OGgwLjAzMmM0NS4xMi0xLjkyLDg4LjQ0OC0yMS40MDgsMTIxLjk4NC01NC45MTJDNTI1LjU3LDIxMi43MDQsNTMwLjY1OCwxMDYuMTQ0LDQ2OC4yOSw0My43NzZ6DQoJCQkgTTQxOS40MjYsNDcuNDI0YzkuNDA4LDUuMTUyLDE4LjQsMTEuMTM2LDI2LjI0LDE5LjAwOGM3Ljg0LDcuODA4LDEzLjg1NiwxNi44LDE5LjAwOCwyNi4yMDhsLTMwLjMzNiwzMC4zMzZMMzg5LjA5LDc3LjcyOA0KCQkJTDQxOS40MjYsNDcuNDI0eiBNMzMyLjUxNCwxMzQuMjcybDMzLjk1Mi0zMy45NTJsNDUuMjQ4LDQ1LjI0OGwtMzMuOTUyLDMzLjk1MkwzMzIuNTE0LDEzNC4yNzJ6IE0zNTUuMTM4LDIwMi4xNDRsLTMzLjk1MiwzMy45NTINCgkJCWwtNDUuMjQ4LTQ1LjI0OGwzMy45NTItMzMuOTUyTDM1NS4xMzgsMjAyLjE0NHogTTM1OS44NDIsMzIuMDMyYzkuMDU2LDAsMTcuOTUyLDEuMTUyLDI2LjY4OCwyLjk3NmwtMjAuMDY0LDIwLjA2NEwzNDQuOTMsMzMuNTM2DQoJCQlDMzQ5LjkyMiwzMy4wMjQsMzU0LjkxNCwzMi4wMzIsMzU5Ljg0MiwzMi4wMzJ6IE0zMDguMzIyLDQyLjE3NmwzNS41MiwzNS41MmwtMzMuOTUyLDMzLjk1MmwtNDQuMTYtNDQuMTYNCgkJCUMyNzkuMDEsNTYuNjQsMjkzLjI1LDQ3Ljk2OCwzMDguMzIyLDQyLjE3NnogTTI0My4wMSw5MC4wMTZsNDQuMjU2LDQ0LjI1NmwtMzMuOTUyLDMzLjk1MmwtMzUuNDU2LTM1LjQ1Ng0KCQkJQzIyMy43NDYsMTE3LjQ3MiwyMzIuMjI2LDEwMy4xMzYsMjQzLjAxLDkwLjAxNnogTTIwNy43NDYsMTc4LjQzMmMwLjEyOC0zLjEzNiwwLjk2LTYuMTQ0LDEuMzEyLTkuMjQ4bDIxLjYzMiwyMS42MzINCgkJCWwtMTkuOTA0LDE5LjkzNkMyMDguNjEsMjAwLjMyLDIwNy4yNjYsMTg5LjYzMiwyMDcuNzQ2LDE3OC40MzJ6IE0yMDIuMTQ2LDMwOS44NTZsMS41NjgtMzYuNjA4DQoJCQljNC44LDYuNzUyLDkuNzI4LDEzLjQ0LDE1LjY4LDE5LjM5MmM1Ljg4OCw1LjkyLDEyLjQ0OCwxMC45MTIsMTkuMTM2LDE1LjY4TDIwMi4xNDYsMzA5Ljg1NnogTTI2OC4yNTgsMjg5LjAyNA0KCQkJYy05LjUwNC01LjIxNi0xOC41MjgtMTEuMjY0LTI2LjI0LTE5LjAwOGMtNy43NzYtNy43NDQtMTMuODI0LTE2Ljc2OC0xOS4wNC0yNi4yNGwzMC4zMDQtMzAuMzA0bDQ1LjI0OCw0NS4yNDhMMjY4LjI1OCwyODkuMDI0eg0KCQkJIE0zMzMuNTcsMzA0LjI4OGMtMTEuMDcyLDAuNTQ0LTIxLjgyNC0wLjgtMzIuMjg4LTMuMDA4bDE5LjkwNC0xOS45MDRsMjEuNjMyLDIxLjYzMg0KCQkJQzMzOS43MTQsMzAzLjMyOCwzMzYuNzA2LDMwNC4xNiwzMzMuNTcsMzA0LjI4OHogTTM3OS4yNjYsMjk0LjE3NkwzNDMuODEsMjU4LjcybDMzLjk1Mi0zMy45NTJsNDQuMjU2LDQ0LjI1Ng0KCQkJQzQwOC44NjYsMjc5LjgwOCwzOTQuNTMsMjg4LjI4OCwzNzkuMjY2LDI5NC4xNzZ6IE00NDQuNjQyLDI0Ni4zNjhsLTQ0LjI1Ni00NC4yMjRsMzMuOTUyLTMzLjk1MmwzNS4zOTIsMzUuMzkyDQoJCQlDNDYzLjkzOCwyMTguNjg4LDQ1NS41MjIsMjMzLjA1Niw0NDQuNjQyLDI0Ni4zNjh6IE00NTYuOTYyLDE0NS41NjhsMTkuNzc2LTE5Ljc3NmMyLjc4NCwxMy40NzIsMy40ODgsMjcuMzkyLDEuOTIsNDEuNDcyDQoJCQlMNDU2Ljk2MiwxNDUuNTY4eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8Y2lyY2xlIGN4PSI2NC4wMzQiIGN5PSI2NCIgcj0iNjQiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==" />
                    </div>
                </div>
                <h5 class="mt-3">Tennis</h5>
            </div>
        </div>
        <div class="col" onclick="basicFilter('mini_soccer')">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <div class="border d-flex justify-content-center align-items-center category-image shadow-sm" style="border-radius: 50%">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyIDUxMiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGQ9Ik0yNTYsMEMxMTQuODQ4LDAsMCwxMTQuODQ4LDAsMjU2czExNC44NDgsMjU2LDI1NiwyNTZzMjU2LTExNC44NDgsMjU2LTI1NlMzOTcuMTUyLDAsMjU2LDB6IE0yNzIuMjU2LDgzLjE2OA0KCQkJbDY1LjgyNC0zNS4zOTJjMzYuNDQ4LDE0LjQzMiw2OC4yNTYsMzguMDgsOTIuNDQ4LDY4LjE2bC0xNS42OCw3Mi4zODRsLTUwLjIwOCwyNC42MDhsLTkyLjM4NC02Ny4yOTZWODMuMTY4eiBNMTc0LjQ2NCw0Ny41ODQNCgkJCWw2NS44MjQsMzUuNTJ2NjIuNTI4bC05Mi4zMiw2Ny4yOTZsLTUwLjQ2NC0yNC42NGwtMTUuNjgtNzIuODMyQzEwNi4wOCw4NS40NCwxMzcuOTUyLDYxLjkyLDE3NC40NjQsNDcuNTg0eiBNNzEuMzYsMzgyLjUyOA0KCQkJYy0yMC44OTYtMzAuNC0zNC40OTYtNjYuMTQ0LTM4LjI0LTEwNC43NjhsNTQuMTc2LTU4Ljg0OGw0OS40MDgsMjQuMTZsMzcuMjE2LDEwNS42OTZsLTMxLjQ1NiwzNy42OTZMNzEuMzYsMzgyLjUyOHoNCgkJCSBNMzEzLjA1Niw0NzIuMzUyQzI5NC43ODQsNDc3LjE4NCwyNzUuNzQ0LDQ4MCwyNTYsNDgwYy0yMy44NzIsMC00Ni44NDgtMy44NC02OC40NDgtMTAuNzg0bC0yMC4xMjgtNjIuNjU2TDE5OS41MiwzNjhoMTEzLjA4OA0KCQkJbDMxLjUyLDM3LjMxMkwzMTMuMDU2LDQ3Mi4zNTJ6IE0zNjkuMDg4LDM4NS4zNzZsLTMwLjk0NC0zNi42NGwzNy43MjgtMTA1LjY2NGw0OS4xODQtMjQuMDk2bDUzLjg1Niw1OC44MTYNCgkJCWMtMy4yMzIsMzMuMzEyLTEzLjk1Miw2NC4zODQtMzAuMjQsOTEuODcyTDM2OS4wODgsMzg1LjM3NnoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==" />
                    </div>
                </div>
                <h5 class="mt-3">Mini Soccer</h5>
            </div>
        </div>
    </div>
    <small class="text-muted fst-italic">Icons made by <a href="https://www.flaticon.com/authors/pixel-perfect" title="Pixel perfect">Pixel perfect</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></small>
</div>

<div id="categoryFilter" class="px-xl-5 px-lg-4 px-md-3 px-2 my-md-4 my-3 w-100 d-none">
    <h5>Some of our field for <span id="basicFilterId"></span> <a href="{{ route('fieldlist') }}" class="text-muted fst-italic" style="font-size: .85rem">Advanced search</a></h5>
    <div class="row row-cols-lg-4 row-cols-md-3 row-cols-2 g-3 mt-2"></div>
</div>

<div class="px-xl-5 px-lg-4 px-md-3 px-2 my-md-4 my-3 w-100">
    <h5>Recent Products <a href="{{ route('productlist') }}" class="text-muted fst-italic" style="font-size: .85rem">more products!</a></h5>
    <div class="row row-cols-xl-5 row-cols-lg-4 row-cols-md-3 row-cols-2 g-3 mt-2">
        @foreach($products as $product)
            <div id="productCard" class="col" data-id="{{ $product->id }}">
                <div class="card">
                    <img type="button" src="{{ json_decode($product->images)[0] }}" class="card-img-top" alt="" onclick="loadProductModal(this)">
                    <div class="card-body text-center">
                        <h5 type="button" class="card-title" onclick="loadProductModal(this)">{{ $product->name }}</h5>
                        <p class="fw-bold fs-3">Rp {{ $product->price }}</p>
                        <a href="https://wa.me/{{ $product->wa }}?text=*Hallo%20Sportpedia%20Merchant!*" target="_blank">
                            <button class="btn btn-success px-3">
                                <i class="fab fa-whatsapp me-2"></i>
                                Order Now
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<div id="productModal" class="modal fade" aria-labelledby="productModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-fullscreen-md-down">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-5">
                        <div id="gallery"></div>
                    </div>
                    <div class="col-md-7 mt-md-0 mt-2">
                        <div class="text-md-start text-center">
                            <h4 class="fw-bold" id="productName"></h4>
                            <p id="productInformation"></p>
                            <h4 id="productPrice" class="fw-bolder"></h4>
                        </div>
                        <div class="d-flex justify-content-md-end justify-content-center mt-md-0 mt-3">
                            <a id="productWa" href="" target="_blank">
                                <button class="btn btn-success px-3">
                                    <i class="fab fa-whatsapp me-2"></i>
                                    Order Now
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="mt-3 px-md-4 px-2 text-light py-3 text-center" style="background-color: #003789">
    <span>Copyright &copy; <span class="fw-bold">Sportpedia Indonesia</span></span>
</footer>

<script>
    $(document).ready(function(){
        $.each(JSON.parse($('#hidden-product').text()), function(i, data){
            _products.push(data);
        });
        $('#hidden-product').remove();
    });
</script>
@endsection
