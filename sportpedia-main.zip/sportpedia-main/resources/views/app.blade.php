<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    @yield('title')

    <link rel="icon" href="{{ asset('images/logo_title.ico') }}" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    @yield('css')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha512-RXf+QSDCUQs5uwRKaDoXt55jygZZm2V++WUZduaU/Ui/9EGp3f/2KZVahFZBKGH0s774sd3HmrhUy+SgOFQLVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/90ecab710e.js" crossorigin="anonymous"></script>
    <script src="{{ asset('js/common.js') }}"></script>
    @yield('js')

    @yield('inline-style')
    <style>
        .img-circle {
            float: left;
            border-radius: 50%;
        }

        .img-circle.img-circle-sm {
            width: 30px;
            height: 30px;
        }

        .img-circle.img-circle-lg {
            width: 100px;
            height: 100px;
        }

        .img-circle.img-circle-xl {
            width: 200px;
            height: 200px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light shadow-sm fixed-top p-0" style="background-color: #0050d1">
        <div class="px-lg-5 px-md-4 px-2 d-flex justify-content-between align-items-center w-100">
            <a class="navbar-brand" href="/">
                <img src="{{ asset('images/logo_header.webp') }}" alt="" width="130">
            </a>
            <a class="px-2 text-white" data-bs-toggle="offcanvas" href="#accountMenuDrawer" role="button" aria-controls="accountMenuDrawer">
                @if(Auth::check())
                    <img src="{{ json_decode(auth()->user()->google)->picture }}" referrerpolicy="no-referrer" class="img-circle img-circle-sm" alt="User Image" />
                @else
                    <span class="img-circle img-circle-sm">
                        <i class="fas fa-user-circle fa-2x"></i>
                    </span>
                @endif
            </a>
            <div class="offcanvas offcanvas-end bg-white" style="width: 200px" tabindex="-1" id="accountMenuDrawer" aria-labelledby="accountMenuDrawerLabel">
                <div class="offcanvas-header d-block shadow-sm" style="background-color: #0050d1">
                    <div class="row">
                        <div class="d-flex justify-content-start">
                            <button type="button" class="btn m-0 text-white p-0" data-bs-dismiss="offcanvas">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        @if(Auth::check())
                            <div class="d-flex justify-content-center">
                                <img src="{{ json_decode(auth()->user()->google)->picture }}" referrerpolicy="no-referrer" class="img-circle img-circle-lg" alt="User Image" />
                            </div>
                            <div class="d-flex justify-content-center mt-2">
                                <span class="text-white">{{ auth()->user()->name }}</span>
                            </div>
                        @else
                            <div class="d-flex justify-content-center text-white">
                                <i class="fas fa-user-circle fa-7x"></i>
                            </div>
                        @endif
                    </div>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav ps-2">
                        @if(Auth::check())
                            @if(in_array(\App\Utility\Role::Manager, json_decode(auth()->user()->role)))
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="{{ route('manager.field') }}">
                                        <div class="row">
                                            <div class="col-1">
                                                <i class="fas fa-map"></i>
                                            </div>
                                            <div class="col">
                                                Fields
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            @endif
                            @if(in_array(\App\Utility\Role::Merchant, json_decode(auth()->user()->role)))
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="{{ route('manager.product') }}">
                                        <div class="row">
                                            <div class="col-1">
                                                <i class="fas fa-shopping-bag"></i>
                                            </div>
                                            <div class="col">
                                                Products
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            @endif
                            @if(in_array(\App\Utility\Role::Admin, json_decode(auth()->user()->role)))
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="{{ route('admin.userlist') }}">
                                        <div class="row">
                                            <div class="col-1">
                                                <i class="fas fa-users"></i>
                                            </div>
                                            <div class="col">
                                                Users
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            @endif
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="{{ route('profile') }}">
                                    <div class="row">
                                        <div class="col-1">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="col">
                                            Profile
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="{{ route('logout') }}">
                                    <div class="row">
                                        <div class="col-1">
                                            <i class="fas fa-sign-out-alt fa-flip-horizontal"></i>
                                        </div>
                                        <div class="col">
                                            Logout
                                        </div>
                                    </div>
                                </a>
                            </li>
                        @else
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="{{ route('login') }}">
                                    <div class="row">
                                        <div class="col-1">
                                            <i class="fas fa-sign-out-alt"></i>
                                        </div>
                                        <div class="col">
                                            Login
                                        </div>
                                    </div>
                                </a>
                            </li>
                        @endif
                    </ul>
                    <div class="alert alert-info" role="alert">
                        <small>Contact our support if you want to be a Field Manager or Product Merchant!</small>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="position-fixed" style="bottom: 5%; left: 5%; z-index: 2000">
        <a href="https://wa.me/6288213536828?text=*Halo%20team%20sportpedia!%20mau%20tanya%20dong!*" target="_blank">
            <button class="btn text-light shadow p-0" style="width: 60px; height: 60px; border-radius: 50%; background-color: #0050d1">
                <i class="fas fa-headset fa-2x"></i>
            </button>
        </a>
    </div>
    @yield('body')
</body>
</html>
