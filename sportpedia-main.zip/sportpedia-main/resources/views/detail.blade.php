@extends('app')

@section('title')
    <title>Sportpedia</title>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/unite-gallery.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/default/ug-theme-default.css') }}">
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.css'/>
    <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.css" type="text/css">
@endsection

@section('js')
    <script src="{{ asset('js/unitegallery.js') }}"></script>
    <script src="{{ asset('themes/grid/ug-theme-grid.js') }}"></script>
    <script src='https://api.mapbox.com/mapbox-gl-js/v2.4.1/mapbox-gl.js'></script>
    <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.7.2/mapbox-gl-geocoder.min.js"></script>
    <script src="{{ asset('js/mapbox.js') }}"></script>
@endsection

@section('inline-style')
    <style>
        .responsive-side {
            position: fixed;
        }

        @media (max-width: 991px) {
            .responsive-side {
                position: relative;
            }
        }

        @media (max-width: 767px) {
            .d-md-block {
                display: none !important;
            }
        }
    </style>
@endsection

@section('body')
    <div class="px-lg-5 px-md-4 px-2 pt-5">
        <div class="py-4">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h4 class="card-title">{{ $field->name }}</h4>
                            <p class="badge rounded-pill border border-danger text-danger">{{ \App\Utility\Field::getString($field->type) }}</p>
                            <div id="gallery" class="rounded">
                                @foreach(json_decode($field->images) as $image)
                                    <img src="{{ $image }}" alt="" data-image="{{ $image }}" data-description="Example Image">
                                @endforeach
                            </div>
                            <div class="row my-3">
                                <div class="col-md-8">
                                    <small class="text-muted">{{ $field->information }}</small>
                                </div>
                                <div class="col-md-4 ps-md-3">
                                    <div class="float-end">
                                        <span>Managed by <span class="text-info">{{ \App\Models\User::find($field->owner)->name }}</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row my-2">
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <span class="fw-bold">Open Hours</span>
                                            <div class="row">
                                                <div class="col"><small>Everyday</small></div>
                                                <div class="col"><small>: {{ json_decode($field->opening_hours)->open }} - {{ json_decode($field->opening_hours)->close }}</small></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mt-md-0 mt-2">
                                            <span class="fw-bold">Prices</span>
                                            @foreach(json_decode($field->prices) as $price)
                                                <div class="row">
                                                    <div class="col"><small>{{ $price->name }}</small></div>
                                                    <div class="col"><small>: {{ $price->value }}</small></div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 ps-md-3">
                                    <div class="d-md-block h-100">
                                        <div class="position-relative h-100">
                                            <a href="https://wa.me/{{ $field->wa }}">
                                                <button class="position-absolute end-0 bottom-0 btn btn-success rounded-pill px-4">
                                                    <i class="fab fa-whatsapp"></i>
                                                    Book Now
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="d-md-none mt-md-0 mt-2">
                                        <div class="float-end">
                                            <a href="https://wa.me/{{ $field->wa }}">
                                                <button class="btn btn-success rounded-pill px-4">
                                                    <i class="fab fa-whatsapp"></i>
                                                    Book Now
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow-sm mt-3">
                        <div class="card-body">
                            <h4 class="card-title">Location Info</h4>
                            <small class="text-muted mt-1">
                                <i class="fas fa-map-marker-alt"></i>
                                {{ $field->address }}
                            </small>
                            <div id="map" class="my-2" data-lng="{{ json_decode($field->location)->lng }}" data-lat="{{ json_decode($field->location)->lat }}"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 ps-lg-3 mt-lg-0 mt-3">
                    <h5>Others managed by <span class="text-info">{{ \App\Models\User::find($field->owner)->name }}</span></h5>
                    @foreach($others as $other)
                        <div class="card mt-3 shadow-sm">
                            <div class="row g-0">
                                <div class="col-4">
                                    <img src="{{ $other['image'] }}" alt="" class="img-fluid rounded-start" style="height: 100%">
                                </div>
                                <div class="col-8">
                                    <div class="card-body" style="font-size: .75rem">
                                        <p class="card-title text-truncate fs-5">{{ $other['name'] }}</p>
                                        <div class="d-flex">
                                            <div class="d-flex align-items-center">
                                                <span class="badge rounded-pill border border-danger text-danger mb-1">{{ \App\Utility\Field::getString($other['type']) }}</span>
                                            </div>
                                            <p class="ms-2 my-0 text-mutes text-truncate">
                                                <i class="fas fa-map-marker-alt"></i>
                                                {{ $other['location'] }}
                                            </p>
                                        </div>
                                        <span>Managed by <span class="text-info">{{ \App\Models\User::find($other['owner'])->name }}</span></span>
                                        <div class="row mt-1">
                                            <div class="col">
                                                @if($other['price_min'] == $other['price_max'])
                                                    <span class="text-danger text-truncate fw-bold">Rp {{ $other['price_min'] }}</span>
                                                @else
                                                    <span class="text-danger text-truncate fw-bold">Rp {{ $other['price_min'] }}-Rp {{ $other['price_max'] }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $('#gallery').unitegallery({
                gallery_theme: 'grid',
                theme_hide_panel_under_width: 1200,
                gridpanel_vertical_scroll: false,
                grid_num_cols: 1,
                slider_enable_text_panel: false,
                gallery_autoplay: true,
                gallery_play_interval: 3000,
            });
            let mapParentWidth = $('#map').parent().width();
            $('#map').css('width', mapParentWidth).css('height', 0.5*mapParentWidth);
            let map = loadMap('map', [$('#map').data('lng'), $('#map').data('lat')]);
            addControl(map, new mapboxgl.NavigationControl(), 'bottom-right');
            addControl(map, new mapboxgl.FullscreenControl(), 'top-right');
            if($(window).width() > 991) {
                addControl(map, new MapboxGeocoder({
                    accessToken: mapboxgl.accessToken,
                    localGeocoder: coordinatesGeocoder,
                    zoom: 13,
                    placeholder: 'Search...',
                    mapboxgl: mapboxgl,
                    reverseGeocode: true
                }), 'top-left');
            }

            addMarker(map, [$('#map').data('lng'), $('#map').data('lat')], '#DF2E2E');
            let navBtn = new MapboxGLButtonControl({
                title: 'Go to Navigation',
                eventHandler: goToNav
            });
            addControl(map, navBtn, 'bottom-right');
        });
    </script>
@endsection
