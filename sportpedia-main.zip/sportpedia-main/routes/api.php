<?php

use App\Http\Controllers\FieldController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//Field
//Route::get('/field', [FieldController::class, 'getFieldById']);
Route::post('/field', [FieldController::class, 'createField']);
Route::get('/manager/field', [FieldController::class, 'getFieldByUser']);
Route::get('/field/list', [FieldController::class, 'getListPagination']);
Route::get('/field', [FieldController::class, 'basicFilter']);
Route::put('/field', [FieldController::class, 'updateField']);
Route::delete('/field', [FieldController::class, 'deleteField']);
Route::put('/field/restore', [FieldController::class, 'restoreField']);

//Product
Route::post('/product', [ProductController::class, 'createProduct']);
Route::get('/manager/product', [ProductController::class, 'getProductByUser']);
Route::put('/product', [ProductController::class, 'updateProduct']);
Route::delete('/product', [ProductController::class, 'deleteProduct']);
Route::put('/product/restore', [ProductController::class, 'restoreProduct']);
Route::get('/product/list', [ProductController::class, 'getListPagination']);

//User
Route::get('/user/filter', [UserController::class, 'userFilter']);
Route::get('/user/field/filter', [UserController::class, 'fieldUserFilter']);
Route::get('/user/product/filter', [UserController::class, 'productUserFilter']);
Route::get('/user/inactivate', [UserController::class, 'inactivateUser']);
Route::get('/user/field/inactive', [UserController::class, 'inactivateFieldUser']);
Route::get('/user/product/inactive', [UserController::class, 'inactiveProductUser']);
Route::get('/user/field/assign', [UserController::class, 'assignFieldUser']);
Route::get('/user/product/assign', [UserController::class, 'assignProductUser']);
Route::get('/user/activate', [UserController::class, 'activateUser']);
Route::put('/profile', [UserController::class, 'updateProfile']);
