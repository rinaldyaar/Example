<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\FieldController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
Route::get('/', function(){
    $repo = new \App\Repositories\ProductRepository();
    $products = $repo->getProductAll()->take(10)->map(function($data){
        $data->price = number_format($data->price, 0, ',', '.');
        return $data;
    });
    return view('homepage')->with(['products'=>$products]);
})->name('home');
Route::get('/field/list', function () {
    return view('fieldList');
})->name('fieldlist');
Route::get('/product/list', function () {
    return view('productList');
})->name('productlist');
Route::get('/detail', [FieldController::class, 'getFieldById'])->name('detail');
Route::get('/manager/field', function(){
    return view('manager.field');
})->name('manager.field');
Route::get('/manager/field/create', function(){
    return view('manager.create_field');
})->name('manager.create_field');
Route::get('/manager/field/operation', function(Request $request){
    if(!$request->has('type')) return abort('404');
    if(!$request->has('id')) return abort('404');
    $repo = new \App\Repositories\FieldRepository();
    return view('manager.viewEditField')->with(['operation'=>ucfirst($request->query('type')), 'field'=>$repo->getFieldById($request->query('id'))]);
});

Route::get('/manager/product', function(){
    return view('manager.product');
})->name('manager.product');
Route::get('/manager/product/create', function(){
    return view('manager.createProduct');
})->name('manager.createProduct');
Route::get('/manager/product/operation', function(Request $request){
    if(!$request->has('type')) return abort('404');
    if(!$request->has('id')) return abort('404');
    $repo = new \App\Repositories\ProductRepository();
    return view('manager.viewEditProduct')->with(['operation'=>ucfirst($request->query('type')), 'product'=>$repo->getProductById($request->query('id'))]);
});

Route::get('auth/google', [AuthController::class, 'redirectToGoogle'])->name('login');
Route::get('auth/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('auth/google/callback', [AuthController::class, 'googleCallback']);

Route::get('profile', function (){
    return view('profile')->with(['user'=>auth()->user()]);
})->name('profile');

Route::get('userlist', function(){
    if(!in_array(\App\Utility\Role::Admin, json_decode(auth()->user()->role))) return abort(404);

    return view('admin.userlist');
})->name('admin.userlist');
