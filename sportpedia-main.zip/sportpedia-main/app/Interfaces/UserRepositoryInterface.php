<?php

namespace App\Interfaces;

use App\Models\User;

interface UserRepositoryInterface
{
    public function createUser(User $user);
    public function assignUserAs($id, $role);
    public function getUserAll($sortBy = 'created_at', $isAsc = false);
    public function getUserById($id);
    public function updateUser(User $user);
    public function deleteUser($id);
    public function deleteUserAs($id, $role);
    public function restore($id);
    public function getUserByGoogle($googleUser);
    public function getUserFilter($status = 0, $filter = array(), $limit = 20);
}
