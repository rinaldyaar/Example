<?php

namespace App\Interfaces;

use App\Models\Product;

interface ProductRepositoryInterface
{
    public function createProduct(Product $product);
    public function getProductAll($sortBy = 'created_at', $isAsc = false);
    public function getAllByUser($userId, $select = array(), $isExcept = false);
    public function getProductById($id);
    public function updateProduct(Product $product);
    public function deleteProduct($id);
    public function deleteProductByUser($userId);
    public function restoreProduct($id);
    public function restoreProductByUser($userId);
    public function getListFilter($count, $filter = array());

}
