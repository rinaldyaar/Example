<?php


namespace App\Interfaces;

use App\Models\Field;

interface FieldRepositoryInterface
{
    public function createField(Field $field);
    public function getFieldAll($sortBy = 'created_at', $isAsc = false);
    public function getFieldById($id);
    public function updateField(Field $field);
    public function deleteField($id);
    public function restoreField($id);
    public function deleteFieldByUser($userId);
    public function restoreFieldByUser($userId);
    public function getWithWhereAndQuery($query = array());
    public function getAllByUser($userId, $select = array(), $isExcept = false);
    public function getPagination($page, $count, $filter);
    public function getFieldByType($type, $take = 5);
}
