<?php

namespace App\Utility;

class Field
{
    const BASKET = 1;
    const BADMINTON = 2;
    const FUTSAL = 3;
    const VOLLEY = 4;
    const TENNIS = 5;
    const SOCCER = 6;
    const TABLE_TENNIS = 7;
    const MINI_SOCCER = 8;

    public static function toArray(){
        return array(self::BASKET,
            self::BADMINTON,
            self::FUTSAL,
            self::VOLLEY,
            self::TENNIS,
            self::SOCCER,
            self::TABLE_TENNIS,
            self::MINI_SOCCER);
    }

    public static function getString($type){
        switch (intval($type)){
            case self::BASKET:
                return 'Basket';
            case self::BADMINTON:
                return 'Badminton';
            case self::FUTSAL:
                return 'Futsal';
            case self::VOLLEY:
                return 'Volley';
            case self::TENNIS:
                return 'Tennis';
            case self::SOCCER:
                return 'Soccer';
            case self::TABLE_TENNIS:
                return 'Table Tennis';
            case self::MINI_SOCCER:
                return 'Mini Soccer';
        }
    }

    public static function getId($fieldType){
        switch (strtolower($fieldType)){
            case 'basket':
                return self::BASKET;
            case 'badminton':
                return self::BADMINTON;
            case 'futsal':
                return self::FUTSAL;
            case 'volley':
                return self::VOLLEY;
            case 'tennis':
                return self::TENNIS;
            case 'soccer':
                return self::SOCCER;
            case 'table tennis':
                return self::TABLE_TENNIS;
            case 'mini soccer':
                return self::MINI_SOCCER;
        }
    }
}
