<?php


namespace App\Utility;


class Common
{
    public static function curl($endpoint, $requestBody = array(), $method = 'GET'){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $endpoint);
        if($method == 'POST') curl_setopt($curl, CURLOPT_POSTFIELDS, $requestBody);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }

    public static function countDistanceMap($from, $to){
        $theta = $from['lng'] - $to->lng;
        $dist = sin(deg2rad($from['lat'])) * sin(deg2rad($to->lat)) +  cos(deg2rad($from['lat'])) * cos(deg2rad($to->lat)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        return $miles * 1.609344;
    }
}
