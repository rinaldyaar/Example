<?php

namespace App\Utility;

class Role
{
    const Admin = 1;
    const Manager = 2; //Field Manager
    const Merchant = 3; //Product Merchant
    const Common = 4;
}
