<?php

namespace App\Http\Controllers;

use App\Interfaces\FieldRepositoryInterface;
use App\Interfaces\UserRepositoryInterface;
use App\Models\Field;
use App\Models\User;
use App\Utility\Common;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class FieldController extends Controller
{
    private $userRepository;
    private $fieldRepository;

    public function __construct(UserRepositoryInterface $userRepository,
                                FieldRepositoryInterface $fieldRepository)
    {
        $this->userRepository = $userRepository;
        $this->fieldRepository = $fieldRepository;
    }

    public function getFieldById(Request $request){
        if (!$request->has('id')){
            return response()->json([
                'message' => 'Query with key id not found!',
                'data' => null
            ], Response::HTTP_BAD_REQUEST);
        }

        $field = $this->fieldRepository->getFieldById($request->query('id'));
        $others = $this->fieldRepository->getWithWhereAndQuery(array(
            array('id', '!=', $field->id),
            array('owner', $field->owner)
        ));
        if(count($others) > 5){
            $others = $others->random(5);
        }
        $others = $others->map(function($data){
            $result = array();
            $result['name'] = $data->name;
            $result['type'] = $data->type;
            $result['image'] = json_decode($data->images)[0];
            $priceArr = array();
            foreach(json_decode($data->prices) as $price){
                array_push($priceArr, $price->value);
            }
            $result['price_min'] = min($priceArr);
            $result['price_max'] = max($priceArr);
            $result['owner'] = $data->owner;
            $locationJson = json_decode($data->location);
            $endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'.$locationJson->lng.','.$locationJson->lat.'.json?types=place&access_token='.env('MAPBOX_API_KEY');
            $location = Str::replace(', Indonesia', '', json_decode(Common::curl($endpoint))->features[0]->place_name);
            $result['location'] = $location;

            return $result;
        });

        return view('detail')->with(['field'=>$field, 'others'=>$others]);
    }

    public function createField(Request $request){
        $newField = new Field();
        $newField->name = $request->input('name');
        $newField->type = intval($request->input('type'));
        $newField->information = $request->input('information');
        $newField->opening_hours = $request->input('hours');
        $newField->prices = $request->input('prices');
        $newField->wa = $request->input('wa');
        $newField->address = $request->input('address');
        $newField->owner = auth()->user()->id;

        $images = $request->file('images');
        $destinationDir = '/upload/'.auth()->user()->name.'/'.$newField->name;
        $files = array();
        foreach ($images as $image){
            if(!file_exists(public_path(Str::substr($destinationDir, 1, strlen($destinationDir)).'/'.$image->getClientOriginalName()))){
                $image->move(Str::substr($destinationDir, 1, strlen($destinationDir)), $image->getClientOriginalName());
                array_push($files, $destinationDir.'/'.$image->getClientOriginalName());
            }
        }
        $newField->images = json_encode($files);
        $newField->location = $request->input('location');
        $priceArr = array();
        foreach(json_decode($newField->prices) as $price){
            array_push($priceArr, $price->value);
        }
        $newField->price_min = intval(min($priceArr));
        $newField->price_max = intval(max($priceArr));

        if($this->fieldRepository->createField($newField)){
            return response()->json([
                'message' => 'Field creation success!',
                'data' => null
            ], Response::HTTP_CREATED);
        }else{
            return response()->json([
                'message' => 'Field creation failed!',
                'data' => null
            ], Response::HTTP_OK);
        }
    }

    public function updateField(Request $request){
        try{
            $id = $request->input('id');
            $field = $this->fieldRepository->getFieldById($id);
            $field->name = $request->input('name');
            $field->type = intval($request->input('type'));
            $field->information = $request->input('information');
            $field->opening_hours = $request->input('hours');
            $field->prices = $request->input('prices');
            $field->wa = $request->input('wa');
            $field->address = $request->input('address');
            $priceArr = array();
            foreach(json_decode($field->prices) as $price){
                array_push($priceArr, $price->value);
            }
            $field->price_min = intval(min($priceArr));
            $field->price_max = intval(max($priceArr));
            $this->fieldRepository->updateField($field);

            return response()->json([
                'message'=>'Update success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getFieldByUser(){
        $userId = auth()->user()->id;
        $fields = $this->fieldRepository->getAllByUser($userId, array('id', 'name', 'type', 'location', 'prices', 'images', 'deleted_at'));
        $othersField = $this->fieldRepository->getAllByUser($userId, array('id', 'owner', 'name', 'type', 'location', 'prices', 'images'), true);

        $result = array();
        $othersResult = array();
        foreach($fields as $field){
            $locationJson = json_decode($field->location);
            $endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'.$locationJson->lng.','.$locationJson->lat.'.json?types=place&access_token='.env('MAPBOX_API_KEY');
            $location = Str::replace(', Indonesia', '', json_decode(Common::curl($endpoint))->features[0]->place_name);
            $priceArr = array();
            foreach(json_decode($field->prices) as $price){
                array_push($priceArr, $price->value);
            }

            array_push($result, array(
                'id'=>$field->id,
                'name'=>$field->name,
                'type'=>\App\Utility\Field::getString($field->type),
                'location'=>$location,
                'price_min'=>min($priceArr),
                'price_max'=>max($priceArr),
                'images'=>json_decode($field->images)[0],
                'status'=>$field->deleted_at == null? 'active': 'inactive'
            ));
        }

        foreach ($othersField as $field){
            $locationJson = json_decode($field->location);
            $endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'.$locationJson->lng.','.$locationJson->lat.'.json?types=place&access_token='.env('MAPBOX_API_KEY');
            $location = Str::replace(', Indonesia', '', json_decode(Common::curl($endpoint))->features[0]->place_name);
            $priceArr = array();
            foreach(json_decode($field->prices) as $price){
                array_push($priceArr, $price->value);
            }
            $user = User::find($field->owner);
            array_push($othersResult, array(
                'id'=>$field->id,
                'name'=>$field->name,
                'type'=>\App\Utility\Field::getString($field->type),
                'location'=>$location,
                'price_min'=>min($priceArr),
                'price_max'=>max($priceArr),
                'images'=>json_decode($field->images)[0],
                'owner'=>$user->name
            ));
        }

        return response()->json([
            'message'=>'',
            'data'=>array(
                'owner_data'=>$result,
                'other_data'=>$othersResult
            )
        ], Response::HTTP_OK);
    }

    public function getListPagination(Request $request){
        $filter = array();
        if($request->has('nearme') && $request->has('lng') && $request->has('lat')){
            $filter['lng'] = $request->query('lng');
            $filter['lat'] = $request->query('lat');
        }else{
            if($request->has('place')){
                $filter['place'] = $request->query('place');
            }
            if($request->has('pricemin')){
                $filter['price_min'] = $request->query('pricemin');
            }
            if($request->has('pricemax')){
                $filter['price_max'] = $request->query('pricemax');
            }
            if($request->has('type')){
                $filter['type'] = $request->query('type');
            }
        }

        $fields = $this->fieldRepository->getPagination(intval($request->query('page')), 4, $filter);

        $result = array();
        if($request->ajax()){
            if($fields != null){
                foreach ($fields as $field){
                    $locationJson = json_decode($field->location);
                    $endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'.$locationJson->lng.','.$locationJson->lat.'.json?types=place&access_token='.env('MAPBOX_API_KEY');
                    $location = Str::replace(', Indonesia', '', json_decode(Common::curl($endpoint))->features[0]->place_name);
                    $priceArr = array();
                    foreach(json_decode($field->prices) as $price){
                        array_push($priceArr, $price->value);
                    }

                    $user = User::find($field->owner);
                    $priceDisplay = min($priceArr) == max($priceArr)?
                        'Rp '.min($priceArr):
                        'Rp '.min($priceArr).'-Rp '.max($priceArr);

                    array_push($result, array(
                        'id'=>$field->id,
                        'name'=>$field->name,
                        'type'=>\App\Utility\Field::getString($field->type),
                        'location'=>$location,
                        'price'=>$priceDisplay,
                        'images'=>json_decode($field->images)[0],
                        'owner'=>$user->name,
                        'wa'=>$field->wa
                    ));
                }
            }

            return response()->json([
                'message'=>'',
                'data'=>$result
            ], Response::HTTP_OK);
        }

        return response()->json([
            'message'=>'Not Ajax request!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);
    }

    public function basicFilter(Request $request){
        if(!$request->has('type')) return response()->json(['message'=>'Type query not found!', 'data'=>null], Response::HTTP_BAD_REQUEST);

        try{
            $typeQuery = $request->query('type');
            $normalizeQuery = str_replace('_', ' ', $typeQuery);
            $fields = $this->fieldRepository->getFieldByType(\App\Utility\Field::getId($normalizeQuery), 6)
                ->map(function($data){
                    $locationJson = json_decode($data->location);
                    $endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'.$locationJson->lng.','.$locationJson->lat.'.json?types=place&access_token='.env('MAPBOX_API_KEY');
                    $location = Str::replace(', Indonesia', '', json_decode(Common::curl($endpoint))->features[0]->place_name);

                    $newData = array();
                    $newData['image'] = json_decode($data->images, true)[0];
                    $newData['title'] = $data->name;
                    $newData['id'] = $data->id;
                    $newData['location'] = $location;

                    return $newData;
                });

            return response()->json([
                'message'=>'Get success',
                'data'=>$fields
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteField(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $this->fieldRepository->deleteField($request->query('id'));
            return response()->json([
                'message'=>'Delete success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function restoreField(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $this->fieldRepository->restoreField($request->query('id'));
            return response()->json([
                'message'=>'Restore success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
