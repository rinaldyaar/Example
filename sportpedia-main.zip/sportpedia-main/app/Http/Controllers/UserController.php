<?php

namespace App\Http\Controllers;

use App\Interfaces\FieldRepositoryInterface;
use App\Interfaces\ProductRepositoryInterface;
use App\Interfaces\UserRepositoryInterface;
use App\Models\User;
use App\Utility\Role;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class UserController extends Controller
{
    private $userRepository;
    private $fieldRepository;
    private $productRepository;

    public function __construct(UserRepositoryInterface $userRepository,
                                FieldRepositoryInterface $fieldRepository,
                                ProductRepositoryInterface $productRepository)
    {
        $this->userRepository = $userRepository;
        $this->fieldRepository = $fieldRepository;
        $this->productRepository = $productRepository;
    }

    public function updateProfile(Request $request){
        $user = User::where('email', $request->input('email'))->first();
        $user->name = $request->input('name');
        $user->wa = $request->input('wa');
        $user->address = $request->input('address');
        $user->location = json_encode($request->input('location'));
        $this->userRepository->updateUser($user);

        return response()->json(['message'=>'Profile update success!'], Response::HTTP_OK);
    }

    public function userFilter(Request $request){
        $filter = array();
        if($request->has('name')){
            array_push($filter, array('name', 'LIKE', '%'.$request->query('name').'%'));
        }
        if($request->has('email')){
            array_push($filter, array('email', 'LIKE', '%'.$request->query('email').'%'));
        }

        $fieldRepo = $this->fieldRepository;
        try{
            $users = $this->userRepository->getUserFilter($request->query('status'), $filter)->map(function($data) use ($fieldRepo){
                $new = array();
                $new['id'] = $data->id;
                $new['name'] = $data->name;
                $new['email'] = $data->email;
                $new['status'] = $data->deleted_at == null? 'Active': 'Inactive';
                $new['fields'] = $fieldRepo->getAllByUser($data->id, array('owner'))->count();

                return $new;
            });

            return response()->json([
                'message'=>'Get success',
                'data'=>$users
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function fieldUserFilter(Request $request){
        $filter = array();
        array_push($filter, array('role', 'LIKE', '%'.Role::Manager.'%'));
        if($request->has('name')) array_push($filter, array('name', 'LIKE', '%'.$request->query('name').'%'));
        if($request->has('email')) array_push($filter, array('email', 'LIKE', '%'.$request->query('email').'%'));

        $fieldRepo = $this->fieldRepository;
        try{
            $users = $this->userRepository->getUserFilter($request->query('status'), $filter)->map(function($data) use ($fieldRepo){
                $new = array();
                $new['id'] = $data->id;
                $new['name'] = $data->name;
                $new['email'] = $data->email;
                $new['fields'] = $fieldRepo->getAllByUser($data->id, array('owner'))->count();

                return $new;
            });
            return response()->json([
                'message'=>'Get success',
                'data'=>$users
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function productUserFilter(Request $request){
        $filter = array();
        array_push($filter, array('role', 'LIKE', '%'.Role::Merchant.'%'));
        if($request->has('name')) array_push($filter, array('name', 'LIKE', '%'.$request->query('name').'%'));
        if($request->has('email')) array_push($filter, array('email', 'LIKE', '%'.$request->query('email').'%'));

        $productRepo = $this->productRepository;
        try{
            $users = $this->userRepository->getUserFilter($request->query('status'), $filter)->map(function($data) use ($productRepo){
                $new = array();
                $new['id'] = $data->id;
                $new['name'] = $data->name;
                $new['email'] = $data->email;
                $new['product'] = $productRepo->getAllByUser($data->id, array('owner'))->count();

                return $new;
            });
            return response()->json([
                'message'=>'Get success',
                'data'=>$users
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function inactivateUser(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $userId = $request->query('id');
            $this->userRepository->deleteUserAs($userId, Role::Manager);
            $this->userRepository->deleteUserAs($userId, Role::Merchant);
            $this->fieldRepository->deleteFieldByUser($userId);
            $this->productRepository->deleteProductByUser($userId);
            $this->userRepository->deleteUser($userId);

            return response()->json([
                'message'=>'Inactivate success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function inactivateFieldUser(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $userId = $request->query('id');
            $this->fieldRepository->deleteFieldByUser($userId);
            $this->userRepository->deleteUserAs($userId, Role::Manager);

            return response()->json([
                'message'=>'Inactivate success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function inactiveProductUser(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        $userId = $request->query('id');
        try{
            $userId = $request->query('id');
            $this->productRepository->deleteProductByUser($userId);
            $this->userRepository->deleteUserAs($userId, Role::Merchant);

            return response()->json([
                'message'=>'Inactivate success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function assignFieldUser(Request $request){
        if(!$request->has('email')) return response()->json([
            'message'=>'No email input found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $filter = array();
            array_push($filter, array('email', $request->query('email')));
            $user = $this->userRepository->getUserFilter(1, $filter, 1);
            if(count($user) == 0) return response()->json([
                'message'=>"User with email {$request->query('email')} not found!",
                'data'=>null
            ], Response::HTTP_NOT_FOUND);

            $this->userRepository->assignUserAs($user[0]->id, Role::Manager);
            $this->fieldRepository->restoreFieldByUser($user[0]->id);
            return response()->json([
                'message'=>'Assign success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function assignProductUser(Request $request){
        if(!$request->has('email')) return response()->json([
            'message'=>'No email input found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $filter = array();
            array_push($filter, array('email', $request->query('email')));
            $user = $this->userRepository->getUserFilter(1, $filter, 1);
            if(count($user) == 0) return response()->json([
                'message'=>"User with email {$request->query('email')} not found!",
                'data'=>null
            ], Response::HTTP_NOT_FOUND);

            $this->userRepository->assignUserAs($user[0]->id, Role::Merchant);
            $this->productRepository->restoreProductByUser($user[0]->id);
            return response()->json([
                'message'=>'Assign success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function activateUser(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        $userId = $request->query('id');
        try{
            $this->userRepository->restore($userId);
            $this->fieldRepository->restoreFieldByUser($userId);
            $this->productRepository->restoreProductByUser($userId);

            return response()->json([
                'message'=>'Activate success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
