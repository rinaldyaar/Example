<?php

namespace App\Http\Controllers;

use App\Interfaces\UserRepositoryInterface;
use App\Models\User;
use App\Utility\Role;
use Exception;
use Illuminate\Auth\Events\Logout;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Laravel\Socialite\Facades\Socialite;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;

class AuthController extends Controller
{
    private $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function redirectToGoogle(){
        return Socialite::driver('google')->stateless()->redirect();
    }

    public function googleCallback(){
        try{
            $googleUser = Socialite::driver('google')->stateless()->user();
            $user = $this->userRepository->getUserByGoogle($googleUser);
            if($user == null){
                $user = new User();
                $user->name = $googleUser->user['name'];
                $user->email = $googleUser->user['email'];
                $user->google = json_encode($googleUser->user);
                $user->role = json_encode(array($user->email == env('APP_EMAIL_ADMIN')? Role::Admin: Role::Common));

                $this->userRepository->createUser($user);
            }

            try {
                if (!$token = JWTAuth::fromUser($user)) {
                    return response()->json(['error' => 'invalid credential'], 400);
                }
            } catch (JWTException $e) {
                return response()->json(['error' => 'failed create token'], 500);
            }

            return redirect('/')->withCookie('_token', $token, env('JWT_TTL'));
        }catch (Exception $e){
            return response()->json(['message'=>$e->getMessage(), 'data'=>null], 500);
        }
    }

    public function logout(){
        try{
            auth()->logout();
        }catch (Exception $e){
            return $e->getMessage();
        }

        return redirect()->route('home');
    }
}
