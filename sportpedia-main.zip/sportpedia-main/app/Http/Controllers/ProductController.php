<?php

namespace App\Http\Controllers;

use App\Interfaces\ProductRepositoryInterface;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    private $productRepository;

    public function __construct(ProductRepositoryInterface $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public function createProduct(Request $request){
        $newProduct = new Product();
        $newProduct->name = $request->input('name');
        $newProduct->information = $request->input('information');
        $newProduct->price = $request->input('price');
        $newProduct->wa = $request->input('wa');
        $newProduct->owner = auth()->user()->id;

        $images = $request->file('images');
        $destinationDir = '/upload/'.auth()->user()->name.'/'.$newProduct->name;
        $files = array();
        foreach ($images as $image){
            if(!file_exists(public_path(Str::substr($destinationDir, 1, strlen($destinationDir)).'/'.$image->getClientOriginalName()))){
                $image->move(Str::substr($destinationDir, 1, strlen($destinationDir)), $image->getClientOriginalName());
                array_push($files, $destinationDir.'/'.$image->getClientOriginalName());
            }
        }
        $newProduct->images = json_encode($files);
        if($this->productRepository->createProduct($newProduct)){
            return response()->json([
                'message' => 'Product creation success!',
                'data' => null
            ], Response::HTTP_CREATED);
        }else{
            return response()->json([
                'message' => 'Product creation failed!',
                'data' => null
            ], Response::HTTP_OK);
        }
    }

    public function getProductByUser(Request $request){
        $userId = auth()->user()->id;
        try{
            $products = $this->productRepository->getAllByUser($userId, array('id', 'name', 'information', 'images', 'price', 'wa', 'deleted_at'));
            $products = $products->map(function($data){
                $data->images = json_decode($data->images);
                $data->price = number_format($data->price, 0, ',', '.');
                return $data;
            });
            return response()->json([
                'message'=>'',
                'data'=>$products
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_OK);
        }
    }

    public function updateProduct(Request $request){
        try{
            $id = $request->input('id');
            $product = $this->productRepository->getProductById($id);
            $product->name = $request->input('name');
            $product->information = $request->input('information');
            $product->price = $request->input('price');
            $product->wa = $request->input('wa');
            $this->productRepository->updateProduct($product);

            return response()->json([
                'message'=>'Update success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteProduct(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $this->productRepository->deleteProduct($request->query('id'));
            return response()->json([
                'message'=>'Delete success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function restoreProduct(Request $request){
        if(!$request->has('id')) return response()->json([
            'message'=>'Query ID not found!',
            'data'=>null
        ], Response::HTTP_BAD_REQUEST);

        try{
            $this->productRepository->restoreProduct($request->query('id'));
            return response()->json([
                'message'=>'Restore success',
                'data'=>null
            ], Response::HTTP_OK);
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListPagination(Request $request){
        $filter = array();
        if($request->has('name')){
            array_push($filter, array('name', 'LIKE', '%'.$request->query('name').'%'));
        }
        if($request->has('pricemin')){
            array_push($filter, array('price', '>=', $request->query('pricemin')));
        }
        if($request->has('pricemax')){
            array_push($filter, array('price', '<=', $request->query('pricemax')));
        }

        try {
            $products = $this->productRepository->getListFilter(5, $filter)->map(function ($data){
                $data->price = number_format($data->price, 0, ',', '.');

                return $data;
            });

            if($request->ajax()){
                return response()->json([
                    'message'=>'',
                    'data'=>$products
                ], Response::HTTP_OK);
            }else{
                return response()->json([
                    'message'=>'Not Ajax request!',
                    'data'=>null
                ], Response::HTTP_BAD_REQUEST);
            }
        }catch (\Exception $e){
            return response()->json([
                'message'=>$e->getMessage(),
                'data'=>null
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function basicFilter(Request $request){

    }
}
