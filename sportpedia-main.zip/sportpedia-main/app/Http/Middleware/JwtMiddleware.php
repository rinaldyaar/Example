<?php

namespace App\Http\Middleware;

use Closure;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Facades\JWTAuth;

class JwtMiddleware
{
    private $exceptUri = [
        //WEB
        '/',
        '/field/list',
        '/product/list',
        '/auth/google',
        '/auth/google/callback',
        '/detail',

        //API
        '/api/field',
        '/api/field/list',
        '/api/product/list'
    ];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if ($request->hasCookie('_token')) {
            $request->headers->add(['Authorization' => 'Bearer ' . Cookie::get('_token')]);
        }

        $uriDestination = $request->getRequestUri();
        if (Str::contains($uriDestination, '?')) {
            $indexEnd = strpos($uriDestination, '?');
            $uriDestinationNorm = substr($uriDestination, 0, $indexEnd);
        } else {
            $uriDestinationNorm = $uriDestination;
        }

        if (in_array($uriDestinationNorm, $this->exceptUri)) {
            return $next($request);
        }

        try {
            $user = JWTAuth::parseToken()->authenticate();
            return $next($request);
        } catch (Exception $e) {
            return redirect()->route('login');
        }
    }
}
