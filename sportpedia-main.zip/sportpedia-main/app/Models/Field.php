<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Field extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'owner',
        'type',
        'information',
        'opening_hours',
        'prices',
        'price_min',
        'price_max',
        'wa',
        'address'
    ];
}
