<?php


namespace App\Repositories;


use App\Interfaces\FieldRepositoryInterface;
use App\Models\Field;
use App\Utility\Common;

class FieldRepository implements  FieldRepositoryInterface
{

    public function createField(Field $field)
    {
        return $field->save();
    }

    public function getFieldAll($sortBy = 'created_at', $isAsc = false)
    {
        $fields = Field::all();
        return $isAsc? $fields->sortBy($sortBy): $fields->sortByDesc($sortBy);
    }

    public function getFieldById($id)
    {
        return Field::find($id);
    }

    public function updateField(Field $field)
    {
        $findField = Field::find($field->id);
        if($findField == null) return null;
        unset($field->id);
        unset($field->created_at);
        unset($field->updated_at);
        unset($field->deleted_at);
        unset($field->images);
        unset($field->location);
        return $findField->update($field->toArray());
    }

    public function deleteField($id)
    {
        return Field::find($id)->delete();
    }

    public function getWithWhereAndQuery($query = array())
    {
        return Field::where($query)->get();
    }

    public function getAllByUser($userId, $select = array(), $isExcept = false)
    {
        return $isExcept?
            Field::select($select)->where('owner', '!=', $userId)->get():
            Field::withTrashed()->select($select)->where('owner', $userId)->get();
    }

    public function getPagination($page, $count, $filter)
    {
        if(count($filter) == 0) return Field::paginate($count);

        if(isset($filter['lng']) && isset($filter['lat'])){
            return Field::all()->map(function($data) use($filter){
                $loc = json_decode($data->location);
                $distance = Common::countDistanceMap($filter, $loc);

                $result = collect();
                $result->id = $data->id;
                $result->name = $data->name;
                $result->owner = $data->owner;
                $result->type = $data->type;
                $result->images = $data->images;
                $result->opening_hours = $data->opening_hours;
                $result->prices = $data->prices;
                $result->price_min = $data->price_min;
                $result->price_max = $data->price_max;
                $result->wa = $data->wa;
                $result->location = $data->location;
                $result->distance = $distance;

                return $result;
            })->sortBy('distance')->forPage($page, $count);
        }else{
            $whereAndQuery = array();
            $whereOrQuery = '';

            if(isset($filter['type'])){
                array_push($whereAndQuery, array(
                    'type', $filter['type']
                ));
            }
            if(isset($filter['price_min'])){
                array_push($whereAndQuery, array(
                    'price_min', '>=', $filter['price_min']
                ));
            }
            if(isset($filter['price_max'])){
                array_push($whereAndQuery, array(
                    'price_max', '<=', $filter['price_max']
                ));
            }
            if(isset($filter['place'])){
                $whereOrQuery = '(`fields`.`name` LIKE \'%'.$filter['place'].'%\' or `fields`.`information` LIKE \'%'.$filter['place'].'%\' or `fields`.`address` LIKE \'%'.$filter['place'].'%\')';
            }


            return $whereOrQuery == ''?
                Field::where($whereAndQuery)->paginate($count):
                Field::where($whereAndQuery)->whereRaw($whereOrQuery)->paginate($count);
        }
    }

    public function getFieldByType($type, $take = 5)
    {
        return Field::where('type', $type)->inRandomOrder()->limit($take)->get();
    }

    public function deleteFieldByUser($userId)
    {
        return Field::where('owner', $userId)->delete();
    }

    public function restoreFieldByUser($userId)
    {
        return Field::onlyTrashed()->where('owner', $userId)->restore();
    }

    public function restoreField($id)
    {
        return Field::onlyTrashed()->where('id', $id)->restore();
    }
}
