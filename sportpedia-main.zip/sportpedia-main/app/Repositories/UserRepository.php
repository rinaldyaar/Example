<?php

namespace App\Repositories;

use App\Interfaces\UserRepositoryInterface;
use App\Models\User;

class UserRepository implements UserRepositoryInterface
{

    public function createUser(User $user)
    {
        return $user->save();
    }

    public function getUserAll($sortBy = 'created_at', $isAsc = false)
    {
        $users = User::all();
        return $isAsc? $users->sortBy($sortBy): $users->sortByDesc($sortBy);
    }

    public function getUserById($id)
    {
        return User::find($id);
    }

    public function updateUser(User $user)
    {
        return $user->save();
    }

    public function deleteUser($id)
    {
        return User::find($id)->delete();
    }

    public function getUserByGoogle($googleUser)
    {
        return User::where('google', json_encode($googleUser->user))->first();
    }

    public function getUserFilter($status = 0, $filter = array(), $limit = 20)
    {
        if ($status == 0){
            return User::withTrashed()->where($filter)->limit($limit)->get();
        }else if($status == 1){
            return User::withoutTrashed()->where($filter)->limit($limit)->get();
        }else{
            return User::onlyTrashed()->where($filter)->limit($limit)->get();
        }
    }

    public function restore($id)
    {
        return User::onlyTrashed()->where('id', $id)->restore();
    }

    public function deleteUserAs($id, $role)
    {
        $user = $this->getUserById($id);
        $roles = collect(json_decode($user->role))->filter(function($r) use ($role){
            return $r != $role;
        });
        $user->role = json_encode($roles);
        return $this->updateUser($user);
    }

    public function assignUserAs($id, $role)
    {
        $user = $this->getUserById($id);
        $roles = json_decode($user->role);
        array_push($roles, $role);
//        dd(json_encode($roles));
        $user->role = json_encode($roles);
        return $this->updateUser($user);
    }
}
