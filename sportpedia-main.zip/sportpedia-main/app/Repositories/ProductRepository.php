<?php

namespace App\Repositories;

use App\Interfaces\ProductRepositoryInterface;
use App\Models\Product;

class ProductRepository implements ProductRepositoryInterface
{

    public function createProduct(Product $product)
    {
        return $product->save();
    }

    public function getProductAll($sortBy = 'created_at', $isAsc = false)
    {
        $products = Product::all();
        return $isAsc? $products->sortBy($sortBy): $products->sortByDesc($sortBy);
    }

    public function getAllByUser($userId, $select = array(), $isExcept = false)
    {
        return $isExcept?
            Product::select($select)->where('owner', '!=', $userId)->get():
            Product::withTrashed()->select($select)->where('owner', $userId)->get();
    }

    public function getProductById($id)
    {
        return Product::find($id);
    }

    public function updateProduct(Product $product)
    {
        $findProduct = Product::find($product->id);
        if($findProduct == null) return null;
        unset($product->id);
        unset($product->created_at);
        unset($product->updated_at);
        unset($product->deleted_at);
        unset($product->images);
        return $findProduct->update($product->toArray());
    }

    public function deleteProduct($id)
    {
        return Product::find($id)->delete();
    }

    public function deleteProductByUser($userId)
    {
        return Product::where('owner', $userId)->delete();
    }

    public function restoreProduct($id)
    {
        return Product::onlyTrashed()->where('id', $id)->restore();
    }

    public function restoreProductByUser($userId)
    {
        return Product::onlyTrashed()->where('owner', $userId)->restore();
    }

    public function getListFilter($count, $filter = array())
    {
        if(count($filter) == 0) return Product::paginate($count);

        return Product::where($filter)->paginate($count);
    }
}
