async function createField(){
    if(self.checkForm()){
        let fd = new FormData();
        fd.append('name', $('#nameInput').val());
        fd.append('type', $('#typeInput option:selected').val());
        fd.append('information', $('#informationInput').val());
        fd.append('hours', JSON.stringify({
            open: $('#startTimeInput').val(),
            close: $('#endTimeInput').val()
        }));
        fd.append('wa', $('#waInput').val());
        fd.append('address', $('#addressInput').val());
        fd.append('location', JSON.stringify({
            lng: $('#locationInput').data('lng') || '',
            lat: $('#locationInput').data('lat') || ''
        }));
        $.each($('#imagesInput').prop('files'), function(i, file){
            fd.append('images[]', file);
        });
        let prices = [];
        $.each($('.price-row'), function(i, row){
            prices.push({
                name: $(row).find('.price-name').val(),
                value: $(row).find('.price-value').val()
            });
        });
        fd.append('prices', JSON.stringify(prices));
        let response = await httpFormData('/api/field', 'post', fd);
        if(response.code === 201){
            window.location.replace('/manager/field');
        }else{
            alert(response.data.message);
        }
    }
}

async function updateField(){
    let prices = [];
    $.each($('.price-row'), function(i, row){
        prices.push({
            name: $(row).find('.price-name').val(),
            value: $(row).find('.price-value').val()
        });
    });

    let response = await http('/api/field', 'put', {
        id: $('#hidden-id').text(),
        name: $('#nameInput').val(),
        type: $('#typeInput option:selected').val(),
        information: $('#informationInput').val(),
        hours: JSON.stringify({
            open: $('#startTimeInput').val(),
            close: $('#endTimeInput').val()
        }),
        wa: $('#waInput').val(),
        address: $('#addressInput').val(),
        prices: JSON.stringify(prices)
    });
    if(response.code === 200){
        window.location.replace('/manager/home');
    }else{
        alert(response.data.message);
    }
}

function openFileInput(element){
    $(element).siblings('.row').empty();
    if($('#imagesInput').prop('files').length > 0){
        $.each($('#imagesInput').prop('files'), function(i, file){
            let reader = new FileReader();
            reader.onload = function(e){
                let img = $('<img>').addClass(['w-100', 'border']).attr('src', e.target.result);
                let div = $('<div>').addClass(['col', 'd-md-block', 'd-flex', 'justify-content-center', 'mt-2']);
                div.append(img);
                $(element).siblings('.row').append(div);
            };
            reader.readAsDataURL(file);
        });
    }
}

function checkForm() {
    let result = [];
    result.push(inputValidation('#nameInput'));
    result.push(selectValidation('#typeInput'));
    result.push(inputValidation('#informationInput'));
    result.push(inputValidation('#imagesInput'));
    result.push(inputValidation('#startTimeInput'));
    result.push(inputValidation('#endTimeInput'));
    result.push(inputValidation('#waInput'));
    result.push(inputValidation('#addressInput'));
    $.each($('.price-name,.price-value'), function(i, input){
        result.push(inputValidation(input));
    });

    if(result.includes(false)){
        alert('Make sure you fill all required form!');
        return false;
    }else{
        return true;
    }
}

function selectValidation(el){
    if($(el).find('option:selected').val() === '0'){
        $(el).addClass('is-invalid').removeClass('is-valid');
        return false;
    }else{
        $(el).addClass('is-valid').removeClass('is-invalid');
        return true;
    }
}

function inputValidation(el){
    if($(el).val() === ''){
        $(el).addClass('is-invalid').removeClass('is-valid');
        return false;
    }else{
        $(el).addClass('is-valid').removeClass('is-invalid');
        return true;
    }
}

function addPrice(element){
    $(element).before('<div class="row mt-3 price-row"><div class="col-md-7 pe-md-3"> <input type="text" class="form-control form-control-sm price-name" placeholder="Price Name"></div><div class="col-md-5"><div class="row mt-md-0 mt-1"><div class="col-8"><div class="input-group input-group-sm"> <span class="input-group-text">Rp</span> <input type="text" class="form-control price-value" placeholder="Price"></div></div><div class="col p-0"> <button class="btn btn-sm border" onclick="removePrice(this)"> <i class="fas fa-times"></i> </button></div></div></div></div>');
}

function removePrice(element){
    if($('#pricesInput .price-name').length === 1){
        $.each($('#pricesInput input'), function(i, input){
            $(input).val('');
        });
    }else{
        $(element).parents('.price-row').remove();
    }
}

function adjustHeight(element){
    $(element).height(($(element).width())*0.75);
}

async function getManagerFieldData(){
    let response = await http('/api/manager/field', 'get');
    if(response.code === 200){
        $.each(response.data.data.owner_data, function(i, data){
            let htmlString = data.status === 'active'?
                '<div class="col"><div class="d-sm-none d-block"><div id="fieldCard" class="card mt-3 shadow-sm card-mobile field%20isactive" data-id="field%20id"><div class="row g-0"><div class="col-4"><img src="field%20image" alt="" class="img-fluid rounded-start" style="height:100%"></div><div class="col-7"><div class="card-body h-100"><h5 class="card-title text-truncate">field%20name</h5><span class="badge rounded-pill border border-danger text-danger mb-1">field%20type</span><br><p class="text-muted mt-1 text-truncate"><i class="fas fa-map-marker-alt me-2"></i>field%20location</p><div class="row"><div class="col"><h4 class="text-danger">field%20price</h4></div></div></div></div><div class="col-1"><div class="btn-group-vertical h-100 w-100"><button type="button" class="btn btn-sm border-start border-bottom d-flex justify-content-center" style="height:33.3333%" onclick="viewFieldManager(this)"><i class="fas fa-eye my-auto"></i></button><button type="button" class="btn btn-sm border-start border-bottom d-flex justify-content-center" style="height:33.3333%" onclick="editFieldManager(this)"><i class="fas fa-edit my-auto"></i></button><button type="button" class="btn btn-sm border-start d-flex justify-content-center" style="height:33.3333%" onclick="deleteFieldManager(this)"><i class="fas fa-trash my-auto"></i></button></div></div></div></div></div><div class="d-sm-block d-none"><div id="fieldCard" class="card h-100 mt-3 shadow-sm card-desktop field%20isactive" title="field%20name" data-id="field%20id"><img src="field%20image" alt="" class="card-img-top height-adjust" onload="adjustHeight(this)"><div class="card-body"><h5 class="card-title text-truncate">field%20name</h5><span class="badge rounded-pill border border-danger text-danger mb-1">field%20type</span><br><p class="text-muted mt-1 text-truncate"><i class="fas fa-map-marker-alt me-2"></i>field%20location</p><h5 class="text-danger">field%20price</h5></div><div class="card-footer btn-group" role="group" style="padding:0"><button type="button" class="btn btn-sm border-end py-2" style="width:33.3333%" onclick="viewFieldManager(this)"><i class="fas fa-eye me-1"></i>View</button><button type="button" class="btn btn-sm border-end py-2" style="width:33.3333%" onclick="editFieldManager(this)"><i class="fas fa-edit me-1"></i>Edit</button><button type="button" class="btn btn-sm py-2" style="width:33.3333%" onclick="deleteFieldManager(this)"><i class="fas fa-trash me-1"></i>Delete</button></div></div></div></div>':
                '<div class="col"><div class="d-sm-none d-block"><div id="fieldCard" class="card mt-3 shadow-sm card-mobile field%20isactive" data-id="field%20id"><div class="row g-0"><div class="col-4"><img src="field%20image" alt="" class="img-fluid rounded-start" style="height:100%"></div><div class="col-7"><div class="card-body h-100"><h5 class="card-title text-truncate">field%20name</h5><span class="badge rounded-pill border border-danger text-danger mb-1">field%20type</span><br><p class="text-muted mt-1 text-truncate"><i class="fas fa-map-marker-alt me-2"></i>field%20location</p><div class="row"><div class="col"><h4 class="text-danger">field%20price</h4></div></div></div></div><div class="col-1"><div class="btn-group-vertical h-100 w-100"><button type="button" class="btn btn-sm border-start d-flex justify-content-center" style="height:33.3333%" onclick="restoreFieldManager(this)"><i class="fas fa-recycle my-auto"></i></button></div></div></div></div></div><div class="d-sm-block d-none"><div id="fieldCard" class="card h-100 mt-3 shadow-sm card-desktop field%20isactive" title="field%20name" data-id="field%20id"><img src="field%20image" alt="" class="card-img-top height-adjust" onload="adjustHeight(this)"><div class="card-body"><h5 class="card-title text-truncate">field%20name</h5><span class="badge rounded-pill border border-danger text-danger mb-1">field%20type</span><br><p class="text-muted mt-1 text-truncate"><i class="fas fa-map-marker-alt me-2"></i>field%20location</p><h5 class="text-danger">field%20price</h5></div><div class="card-footer btn-group" role="group" style="padding:0"><button type="button" class="btn btn-sm border-end py-2" style="width:33.3333%" onclick="restoreFieldManager(this)"><i class="fas fa-recycle me-1"></i>Restore</button></div></div></div></div>';
            htmlString = htmlString.replaceAll('field%20id', data.id);
            htmlString = htmlString.replaceAll('field%20image', data.images);
            htmlString = htmlString.replaceAll('field%20name', data.name);
            htmlString = htmlString.replaceAll('field%20type', data.type);
            htmlString = htmlString.replaceAll('field%20location', data.location);
            htmlString = data.price_min === data.price_max?
                htmlString.replaceAll('field%20price', 'Rp' + data.price_min):
                htmlString.replaceAll('field%20price', 'Rp' + data.price_min + '-' + data.price_max);
            console.log(data.status);
            htmlString = data.status === 'active'? htmlString.replaceAll('field%20isactive', ''): htmlString.replaceAll('field%20isactive', 'card-inactive');
            $('#ownerFieldContainer').append(htmlString);
        });

        $.each(response.data.data.other_data, function(i, data){
            let htmlString = '<div id="cardField" class="card mt-3 shadow-sm" title="field%20name" data-id="field%20id"><div class="row g-0"><div class="col-4"> <img src="field%20image" alt="" class="img-fluid rounded-start" style="height: 100%"></div><div class="col-8"><div class="card-body" style="font-size: .75rem"><p class="card-title text-truncate fs-5">field%20name</p><div class="d-flex"><div class="d-flex align-item-center"> <span class="badge rounded-pill border border-danger text-danger mb-1">field%20type</span></div><p class="ms-2 my-0 text-muted text-truncate"> <i class="fas fa-map-marker-alt me-1"></i>field%20location</p></div> <span>Managed by <span class="text-info">field%20owner</span></span><div class="row mt-1"><div class="col"> <span class="text-danger text-truncate fw-bold">field%20price</span></div></div></div></div></div></div>';
            htmlString = htmlString.replaceAll('field%20id', data.id);
            htmlString = htmlString.replaceAll('field%20image', data.images);
            htmlString = htmlString.replaceAll('field%20name', data.name);
            htmlString = htmlString.replaceAll('field%20type', data.type);
            htmlString = htmlString.replaceAll('field%20location', data.location);
            htmlString = htmlString.replaceAll('field%20owner', data.owner);
            htmlString = data.price_min === data.price_max?
                htmlString.replaceAll('field%20price', 'Rp' + data.price_min):
                htmlString.replaceAll('field%20price', 'Rp' + data.price_min + '-' + data.price_max);
            $('#otherFieldContainer').append(htmlString);
        });
    }
}

async function basicFilter(field){
    let response = await http('/api/field?type='+field, 'get');
    if(response.code === 200){
        if($('#categoryFilter').hasClass('d-none')){
            $('#categoryFilter').removeClass('d-none').addClass('d-block');
        }

        let split = field.split('_');
        $.each(split, function(i, word){
            split[i] = word.charAt(0).toUpperCase() + word.slice(1);
        });
        $('#basicFilterId').text(split.join(' '));

        $('#categoryFilter .row').empty();
        $.each(response.data.data, function(i, data){
            let htmlString = '<div class="col"><div class="card h-100" title="Lapangan UNY"><img src="field%20image" class="card-img-top height-adjust" alt="" onload="adjustHeight(this)"><div class="card-body"><h5 class="card-title">field%20title</h5><span class="text-muted mt-1"><i class="fas fa-map-marker-alt me-1"></i>field%20location</span><div class="text-end"><a href="/detail?id=field%20id" target="_blank">see detail</a></div></div></div></div>';
            htmlString = htmlString.replaceAll('field%20image', data.image);
            htmlString = htmlString.replaceAll('field%20title', data.title);
            htmlString = htmlString.replaceAll('field%20location', data.location);
            htmlString = htmlString.replaceAll('field%20id', data.id);
            $('#categoryFilter .row').append(htmlString);
        });
        window.location.replace('/#categoryFilter');
    }else{
        alert(response.data.message);
    }
}

async function viewFieldManager(element){
    window.location.replace('/manager/field/operation?id=' + $(element).parents('#fieldCard').data('id') + '&type=view');
}

async function editFieldManager(element){
    window.location.replace('/manager/field/operation?id=' + $(element).parents('#fieldCard').data('id') + '&type=edit');
}

async function deleteFieldManager(element){
    let response = await http('/api/field?id=' + $(element).parents('#fieldCard').data('id'), 'delete');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function restoreFieldManager(element){
    let response = await http('/api/field/restore?id=' + $(element).parents('#fieldCard').data('id'), 'put');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}
