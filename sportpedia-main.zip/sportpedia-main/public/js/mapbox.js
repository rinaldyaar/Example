function loadMap(containerId, centerPosition, isClickable = false, zoom = 15){
    mapboxgl.accessToken = 'pk.eyJ1IjoiaWhzYW5zeWFyaWZ1ZGRpbiIsImEiOiJja2o1a25ycHUzMTU5MnFxdG1xY2xncmZwIn0.vFeJX6msCFPJooRP65f2Xg';
    let map = new mapboxgl.Map({
        container: containerId,
        style: 'mapbox://styles/mapbox/streets-v11',
        center: centerPosition,
        zoom: zoom
    });

    if(isClickable){
        let marker = null;
        map.on('click', (e) => {
            if(marker !== null) marker.remove();
            marker = addMarker(map, e.lngLat, '#DF2E2E');
            $('#locationInput').attr('data-lng', e.lngLat.lng).attr('data-lat', e.lngLat.lat);
        });
    }

    return map;
}

function addControl(map, control, position){
    map.addControl(control, position);
}

function addMarker(map, position, color){
    return new mapboxgl.Marker({color: color})
        .setLngLat(position)
        .addTo(map);
}

function coordinatesGeocoder(query){
    const matches = query.match(
        /^[ ]*(?:Lat: )?(-?\d+\.?\d*)[, ]+(?:Lng: )?(-?\d+\.?\d*)[ ]*$/i
    );
    if (!matches) {
        return null;
    }

    function coordinateFeature(lng, lat) {
        return {
            center: [lng, lat],
            geometry: {
                type: 'Point',
                coordinates: [lng, lat]
            },
            place_name: 'Lat: ' + lat + ' Lng: ' + lng,
            place_type: ['coordinate'],
            properties: {},
            type: 'Feature'
        };
    }

    const coord1 = Number(matches[1]);
    const coord2 = Number(matches[2]);
    const geocodes = [];

    if (coord1 < -90 || coord1 > 90) {
        geocodes.push(coordinateFeature(coord1, coord2));
    }

    if (coord2 < -90 || coord2 > 90) {
        geocodes.push(coordinateFeature(coord2, coord1));
    }

    if (geocodes.length === 0) {
        geocodes.push(coordinateFeature(coord1, coord2));
        geocodes.push(coordinateFeature(coord2, coord1));
    }

    return geocodes;
}

function goToNav(){
    window.open('https://www.google.com/maps/search/?api=1&query='+ $('#map').data('lat') +'%2C'+ $('#map').data('lng'),'_blank');
}

class MapboxGLButtonControl {
    constructor({
                    title = "",
                    eventHandler = evtHndlr
                }) {
        this._title = title;
        this._eventHandler = eventHandler;
    }

    onAdd(map) {
        this._icon = document.createElement("i");
        this._icon.className = "fas fa-location-arrow";

        this._btn = document.createElement("button");
        this._btn.className = "mapboxgl-ctrl-icon";
        this._btn.type = "button";
        this._btn.title = this._title;
        this._btn.onclick = this._eventHandler;
        this._btn.appendChild(this._icon);

        this._container = document.createElement("div");
        this._container.className = "mapboxgl-ctrl-group mapboxgl-ctrl";
        this._container.appendChild(this._btn);

        return this._container;
    }

    onRemove() {
        this._container.parentNode.removeChild(this._container);
        this._map = undefined;
    }
}
