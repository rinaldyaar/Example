async function saveProfile(){
    let response = await http('/api/profile', 'put', {
        name: $('#nameInput').val(),
        email: $('#emailInput').val(),
        wa: $('#waInput').val(),
        address: $('#addressInput').val(),
        location: {
            lng: $('#locationInput').attr('data-lng'),
            lat: $('#locationInput').attr('data-lat')
        }
    });
    if(response.code === 200){
        window.location.replace('/manager/home');
    }
}
