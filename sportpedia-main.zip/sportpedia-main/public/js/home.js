let _isNoMore = false;

function getCurrentLocation(){
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(assignPosition);
    } else {
        alert('Geolocation is not supported by this browser');
    }
}

function assignPosition(position){
    $('#myLocationInput').attr('data-lng', position.coords.longitude).attr('lat', position.coords.latitude);
    $('#myLocationInput').val('LngLat: ' + position.coords.longitude + ',' + position.coords.latitude);
    $('#nearMeBtn').attr('disabled', false);
}

function getFieldList(isNearMe = false){
    $('#searchResult').empty();
    $(window).unbind("scroll");
    _isNoMore = false;

    let location = [];
    let filter = '';
    if(isNearMe){
        let locationInput = $('#myLocationInput').val();
        locationInput.replace('LngLat: ', '');
        location = (locationInput.replace('LngLat: ', '')).split(',');
    }else{
        filter += $('#placeInput').val() === ''? '': '&place=' + $('#placeInput').val();
        filter += $('#typeInput option:selected').val() === '0'? '': '&type=' + $('#typeInput option:selected').val();
        filter += $('#priceMin').val() === ''? '': '&pricemin=' + $('#priceMin').val();
        filter += $('#priceMax').val() === ''? '': '&pricemax=' + $('#priceMax').val();
    }

    let page = 1;
    load_more(page, isNearMe, location, filter);

    $(window).scroll(function(){
        if($(window).scrollTop() + $(window).height() >= $(document).height()){
            page++;
            load_more(page, isNearMe, location, filter);
        }
    });
}

function load_more(page, isNearMe, location, filter){
    if(!_isNoMore){
        $.ajax({
            url: isNearMe?'/api/field/list?page=' + page + '&nearme=1&lng='+location[0]+'&lat='+location[1]: '/api/field/list?page='+page + filter,
            type: 'get',
            beforeSend: function(){
                $('.spinner-border').addClass('d-block').removeClass('d-none');
            }
        }).done(function(data){
            if(data.data.length !== 0){
                $.each(data.data, function(i, data){
                    let htmlString = '<div class="card my-3 shadow-sm"><div class="row g-0"><div class="col-4" type="button" data-id="field%20id" onclick="getDetail(this)"><img src="field%20image" alt="" class="img-fluid rounded-start" style="height:100%"></div><div class="col-8"><div class="card-body"><div type="button" data-id="field%20id" onclick="getDetail(this)"><h5 class="card-title text-truncate">field%20name</h5><span class="badge rounded-pill border border-danger text-danger mb-1 me-2">field%20type</span><span class="text-muted mt-1"><i class="fas fa-map-marker-alt me-1"></i>field%20location</span><br><span>Managed by <span class="text-info">field%20owner</span></span></div><div class="row mt-lg-3 mt-md-2 mt-1"><div class="col"><h4 class="text-danger text-truncate">field%20price</h4></div><div class="col-auto"><a href="https://wa.me/field%20wa?text=*Hallo%20Sportpedia%20Merchant!*" target="_blank"><button class="float-end btn btn-sm btn-success rounded-pill px-4"><i class="fab fa-whatsapp"></i>Book Now</button></a></div></div></div></div></div></div>';
                    htmlString = htmlString.replaceAll('field%20id', data.id);
                    htmlString = htmlString.replaceAll('field%20image', data.images);
                    htmlString = htmlString.replaceAll('field%20name', data.name);
                    htmlString = htmlString.replaceAll('field%20type', data.type);
                    htmlString = htmlString.replaceAll('field%20location', data.location);
                    htmlString = htmlString.replaceAll('field%20owner', data.owner);
                    htmlString = htmlString.replaceAll('field%20price', data.price);
                    htmlString = htmlString.replaceAll('field%20wa', data.wa);
                    let result = $(htmlString);
                    result.find('img').css('height', (225 * 0.75) + 'px').css('width', '100%');
                    $('.spinner-border').addClass('d-none').removeClass('d-block');
                    $('#searchResult').append(result);
                })
            }
            else{
                $('.spinner-border').addClass('d-none').removeClass('d-block');
                _isNoMore = true;
            }
        })
    }
}
function getDetail(element){
    window.open('/detail?id='+$(element).data('id'), '_blank');
}
