async function http(endpoint, method, body = null) {
    let response = await fetch(endpoint, {
        method: method,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: body == null ? null : JSON.stringify(body)
    });
    let jsonResponse = await response.json();
    return {
        code: response.status,
        data: jsonResponse
    };
}

async function httpFormData(endpoint, method, body) {
    let response = await fetch(endpoint, {
        method: method,
        body: body
    });
    let jsonResponse = await response.json();
    return {
        code: response.status,
        data: jsonResponse
    };
}
