async function getUserList(){
    let query = [];
    if($('#nameFilter').val() !== ''){
        query.push('name=' + $('#nameFilter').val());
    }
    if($('#emailFilter').val() !== ''){
        query.push('email=' + $('#emailFilter').val());
    }
    query.push('status=' + $('#statusFilter option:selected').val());

    $('#commonUser table tbody').empty();
    $('#commonUser #loadingDiv').addClass('d-block').removeClass('d-none');
    let response = await http('/api/user/filter?' + query.join('&'), 'get');
    $('#commonUser #loadingDiv').addClass('d-none').removeClass('d-block');
    if(response.code){
        $.each(response.data.data, function(i, data){
            let htmlString = data.status === 'Active'?
                '<tr><td>user%20name</td><td>user%20email</td><td class="text-center">user%20status</td><td class="text-center"><button class="btn btn-sm btn-danger" title="Inactivate User" data-id="user%20id" onclick="inactivateUser(this)"><i class="fas fa-user-alt-slash"></i></button></td></tr>':
                '<tr><td>user%20name</td><td>user%20email</td><td class="text-center">user%20status</td><td class="text-center"><button class="btn btn-sm btn-success" title="Activate User" data-id="user%20id" onclick="activateUser(this)"><i class="fas fa-recycle"></i></button></td></tr>';
            htmlString = htmlString.replaceAll('user%20name', data.name);
            htmlString = htmlString.replaceAll('user%20email', data.email);
            htmlString = htmlString.replaceAll('user%20status', data.status);
            htmlString = htmlString.replace('user%20id', data.id);
            $('#commonUser table tbody').append(htmlString);
        });
    }else{
        alert(response.data.message);
    }
}

async function getFieldUserList() {
    let query = [];
    $('#fieldEmailFilter').val() !== ''? query.push('email=' + $('#fieldEmailFilter').val()): '';
    $('#fieldNameFilter').val() !== ''? query.push('name=' + $('#fieldNameFilter').val()): '';
    $('#fieldUser table tbody').empty();
    $('#fieldUser #loadingDiv').addClass('d-block').removeClass('d-none');
    let response = await http('/api/user/field/filter?' + query.join('&'), 'get');
    $('#fieldUser #loadingDiv').addClass('d-none').removeClass('d-block');
    if(response.code === 200){
        $.each(response.data.data, function(i, data){
            let htmlString = '<tr><td>user%20name</td><td>user%20email</td><td class="text-center">user%20fields</td><td class="text-center"> <button class="btn btn-sm btn-danger" title="Inactivate User" data-id="user%20id" onclick="inactivateFieldUser(this)"><i class="fas fa-user-alt-slash"></i> </button></td></tr>';
            htmlString = htmlString.replaceAll('user%20name', data.name);
            htmlString = htmlString.replaceAll('user%20email', data.email);
            htmlString = htmlString.replaceAll('user%20fields', data.fields);
            htmlString = htmlString.replaceAll('user%20id', data.id);
            $('#fieldUser table tbody').append(htmlString);
        });
    }else{
        alert(response.data.message);
    }
}

async function getProductUserList() {
    let query = [];
    $('#productEmailFilter').val() !== ''? query.push('email=' + $('#productEmailFilter').val()): '';
    $('#productNameFilter').val() !== ''? query.push('name=' + $('#productNameFilter').val()): '';
    $('#productUser table tbody').empty();
    $('#productUser #loadingDiv').addClass('d-block').removeClass('d-none');
    let response = await http('/api/user/product/filter?' + query.join('&'), 'get');
    $('#productUser #loadingDiv').addClass('d-none').removeClass('d-block');
    if(response.code === 200){
        $.each(response.data.data, function(i, data){
            let htmlString = '<tr><td>user%20name</td><td>user%20email</td><td class="text-center">user%20products</td><td class="text-center"> <button class="btn btn-sm btn-danger" title="Inactivate User" data-id="user%20id" onclick="inactivateProductUser(this)"><i class="fas fa-user-alt-slash"></i> </button></td></tr>';
            htmlString = htmlString.replaceAll('user%20name', data.name);
            htmlString = htmlString.replaceAll('user%20email', data.email);
            htmlString = htmlString.replaceAll('user%20products', data.product);
            htmlString = htmlString.replaceAll('user%20id', data.id);
            $('#productUser table tbody').append(htmlString);
        });
    }else{
        alert(response.data.message);
    }
}

async function inactivateUser(element){
    let response = await http('/api/user/inactivate?id=' + $(element).data('id'), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function inactivateFieldUser(element){
    let response = await http('/api/user/field/inactive?id=' + $(element).data('id'), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function inactivateProductUser(element){
    let response = await http('/api/user/product/inactive?id=' + $(element).data('id'), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function assignFieldManager(){
    let response = await http('/api/user/field/assign?email=' + $('#assignFieldManager #assignEmailInput').val(), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function assignProductUser(){
    let response = await http('/api/user/product/assign?email=' + $('#assignProductUser #assignEmailInput').val(), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function activateUser(element){
    let response = await http('/api/user/activate?id=' + $(element).data('id'), 'get');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}
