let _products = [];
let _isNoMore = false;

async function getManagerProductData(){
    let response = await http('/api/manager/product', 'get');
    if(response.code === 200){
        _products = response.data.data;
        $.each(response.data.data, function(i, data){
            let htmlString = data.deleted_at === null?
                '<div id="productCard" class="col" data-id="product%20id"><div class="card product%20isactive"> <img src="product%20image" class="card-img-top" alt=""><div class="card-body text-center"><h5 class="card-title">product%20name</h5><span class="fw-bold fs-3">Rp product%20price</span></div><div class="card-footer btn-group p-0"> <button class="btn btn-sm border-end py-2" style="width: 33.3333%" onclick="viewProduct(this)">View</button> <button class="btn btn-sm border-end py-2" style="width: 33.3333%" onclick="editProduct(this)">Edit</button> <button class="btn btn-sm py-2" style="width: 33.3333%" onclick="deleteProduct(this)">Delete</button></div></div></div>':
                '<div id="productCard" class="col" data-id="product%20id"><div class="card product%20isactive"> <img src="product%20image" class="card-img-top" alt=""><div class="card-body text-center"><h5 class="card-title">product%20name</h5><span class="fw-bold fs-3">Rp product%20price</span></div><div class="card-footer btn-group p-0"> <button type="button" class="btn btn-sm border-end py-2 w-100" onclick="restoreProduct(this)"><i class="fas fa-recycle me-1"></i>Restore</button></div></div></div>';
            htmlString = htmlString.replaceAll('product%20id', data.id);
            htmlString = htmlString.replaceAll('product%20image', data.images[0]);
            htmlString = htmlString.replaceAll('product%20name', data.name);
            htmlString = htmlString.replaceAll('product%20price', data.price);
            htmlString = data.deleted_at === null? htmlString.replaceAll('product%20isactive', ''): htmlString.replaceAll('product%20isactive', 'card-inactive');
            $('#productContainer').append(htmlString);
        });
    }else{
        alert(response.data.message);
    }
}

async function createProduct(){
    if(self.checkForm()){
        let fd = new FormData();
        fd.append('name', $('#nameInput').val());
        fd.append('information', $('#informationInput').val());
        fd.append('wa', $('#waInput').val());
        fd.append('price', $('#priceInput').val());
        $.each($('#imagesInput').prop('files'), function(i, file){
            fd.append('images[]', file);
        });
        let response = await httpFormData('/api/product', 'post', fd);
        if(response.code === 201){
            window.location.replace('/manager/product');
        }else{
            alert(response.data.message);
        }
    }
}

function checkForm(){
    let result = [];
    result.push(inputValidation('#nameInput'));
    result.push(inputValidation('#imagesInput'));
    result.push(inputValidation('#priceInput'));
    result.push(inputValidation('#waInput'));

    if(result.includes(false)){
        alert('Make sure you fill all required form!');
        return false;
    }else{
        return true;
    }
}

function inputValidation(el){
    if($(el).val() === ''){
        $(el).addClass('is-invalid').removeClass('is-valid');
        return false;
    }else{
        $(el).addClass('is-valid').removeClass('is-invalid');
        return true;
    }
}

function openFileInput(element){
    $(element).siblings('.row').empty();
    if($('#imagesInput').prop('files').length > 0){
        $.each($('#imagesInput').prop('files'), function(i, file){
            let reader = new FileReader();
            reader.onload = function(e){
                let img = $('<img>').addClass(['w-100', 'border']).attr('src', e.target.result);
                let div = $('<div>').addClass(['col', 'd-md-block', 'd-flex', 'justify-content-center', 'mt-2']);
                div.append(img);
                $(element).siblings('.row').append(div);
            };
            reader.readAsDataURL(file);
        });
    }
}

function loadProductModal(element){
    let productId = $(element).parents('#productCard').data('id');
    let productObj = _products.find(product => product.id.toString() === productId.toString());
    $.each(JSON.parse(productObj.images), function (i, data) {
        $('#gallery').append('<img src="' + data + '" style="object-fit: cover"/>');
    });
    $('#gallery').unitegallery({
        gallery_theme: 'slider',
        slider_scale_mode: "fit",
        slider_scale_mode_media: "fit",
        slider_scale_mode_fullscreen: "down",
    });
    $('#productName').text(productObj.name);
    $('#productInformation').text(productObj.information);
    $('#productPrice').text('Rp ' + productObj.price);
    $('#productWa').attr('href', 'https://wa.me/' + productObj.wa + '?text=*Hallo%20Sportpedia%20Merchant!*');

    $('#productModal').on('hidden.bs.modal', function(){
        $('#gallery').empty();
        $('#productName').text('');
        $('#productInformation').text('');
        $('#productPrice').text('');
        $('#productWa').attr('href', '');
    });
    $('#productModal').modal('show');
}

function viewProduct(element){
    window.location.replace('/manager/product/operation?id=' + $(element).parents('#productCard').data('id') + '&type=view');
}

function editProduct(element){
    window.location.replace('/manager/product/operation?id=' + $(element).parents('#productCard').data('id') + '&type=edit');
}

async function deleteProduct(element){
    let response = await http('/api/product?id=' + $(element).parents('#productCard').data('id'), 'delete');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function restoreProduct(element){
    let response = await http('/api/product/restore?id=' + $(element).parents('#productCard').data('id'), 'put');
    if(response.code === 200){
        window.location.reload();
    }else{
        alert(response.data.message);
    }
}

async function updateProduct(){
    let response = await http('/api/product', 'put', {
        id: $('#hidden-id').text(),
        name: $('#nameInput').val(),
        information: $('#informationInput').val(),
        price: $('#priceInput').val().replaceAll('.', ''),
        wa: $('#waInput').val()
    });
    if(response.code === 200){
        window.location.replace('/manager/product');
    }else{
        alert(response.data.message);
    }
}

async function getProductList(){
    // await http('/api/product/list', 'get');
    $('#searchResult').empty();
    $(window).unbind("scroll");
    _isNoMore = false;

    let filter = '';
    filter += $('#nameFilter').val() === ''? '': '&name=' + $('#nameFilter').val();
    filter += $('#priceMinFilter').val() === ''? '': '&pricemin=' + $('#priceMinFilter').val();
    filter += $('#priceMaxFilter').val() === ''? '': '&pricemax=' + $('#priceMaxFilter').val();
    let page = 1;
    _products = [];

    load_more(page, filter);

    $(window).scroll(function(){
        if($(window).scrollTop() + $(window).height() >= $(document).height()){
            page++;
            load_more(page, filter);
        }
    });
}

function load_more(page, filter){
    if(!_isNoMore){
        $.ajax({
            url: '/api/product/list?page='+page+filter,
            type: 'get',
            beforeSend: function () {
                $('.spinner-border').addClass('d-block').removeClass('d-none');
            }
        }).done(function(data){
            if(data.data.length !== 0){
                $.each(data.data, function(i, data){
                    _products.push(data);
                    let htmlString = '<div id="productCard" class="col" data-id="product%20id"><div class="card"> <img type="button" src="product%20image" class="card-img-top" alt="" onclick="loadProductModal(this)"><div class="card-body text-center"><h5 type="button" class="card-title" onclick="loadProductModal(this)">product%20name</h5><p class="fw-bold fs-3">Rp product%20price</p> <a href="https://wa.me/product%20wa?text=*Hallo%20Sportpedia%20Merchant!*" target="_blank"> <button class="btn btn-success px-3"> <i class="fab fa-whatsapp me-2"></i>Order Now </button> </a></div></div></div>';
                    htmlString = htmlString.replaceAll('product%20id', data.id);
                    htmlString = htmlString.replaceAll('product%20image', JSON.parse(data.images)[0]);
                    htmlString = htmlString.replaceAll('product%20name', data.name);
                    htmlString = htmlString.replaceAll('product%20price', data.price);
                    htmlString = htmlString.replaceAll('product%20wa', data.wa);
                    let result = $(htmlString);
                    result.find('img').css('height', (225 * 0.75) + 'px').css('width', '100%');
                    $('.spinner-border').addClass('d-none').removeClass('d-block');
                    $('#searchResult').append(result);
                });
            }else{
                $('.spinner-border').addClass('d-none').removeClass('d-block');
                _isNoMore = true;
            }
        });
    }
}
